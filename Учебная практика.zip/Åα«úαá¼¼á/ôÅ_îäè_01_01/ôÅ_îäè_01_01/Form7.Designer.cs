﻿namespace УП_МДК_01_01
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.уП01_ИСПП5_Работягова_ААDataSet = new УП_МДК_01_01.УП01_ИСПП5_Работягова_ААDataSet();
            this.квартирыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.квартирыTableAdapter = new УП_МДК_01_01.УП01_ИСПП5_Работягова_ААDataSetTableAdapters.КвартирыTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодДомаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типДомаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.всегоЭтажейВДомеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фотографииЗданияDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.районГородаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.инфраструктураТерриторииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.домаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.домаTableAdapter = new УП_МДК_01_01.УП01_ИСПП5_Работягова_ААDataSetTableAdapters.ДомаTableAdapter();
            this.fKДоговорыКвартирыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.договорыTableAdapter = new УП_МДК_01_01.УП01_ИСПП5_Работягова_ААDataSetTableAdapters.ДоговорыTableAdapter();
            this.fKКвартирыДомаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.кодКвартирыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодДомаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.документНаПравоСобственностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наличиеПриватизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.общаяПлощадьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.этажКвартирыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типПланировкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типСанузлаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.адресКвартирыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.жилаяПлощадьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.площадьКухниDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.планКвартирыDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.fKКвартирыДомаBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.SaveButton = new System.Windows.Forms.ToolStripButton();
            this.CancelButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.уП01_ИСПП5_Работягова_ААDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.квартирыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.домаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKДоговорыКвартирыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKКвартирыДомаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKКвартирыДомаBindingSource1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.SuspendLayout();
            // 
            // уП01_ИСПП5_Работягова_ААDataSet
            // 
            this.уП01_ИСПП5_Работягова_ААDataSet.DataSetName = "УП01_ИСПП5_Работягова_ААDataSet";
            this.уП01_ИСПП5_Работягова_ААDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // квартирыBindingSource
            // 
            this.квартирыBindingSource.DataMember = "Квартиры";
            this.квартирыBindingSource.DataSource = this.уП01_ИСПП5_Работягова_ААDataSet;
            // 
            // квартирыTableAdapter
            // 
            this.квартирыTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодДомаDataGridViewTextBoxColumn,
            this.типДомаDataGridViewTextBoxColumn,
            this.всегоЭтажейВДомеDataGridViewTextBoxColumn,
            this.фотографииЗданияDataGridViewImageColumn,
            this.районГородаDataGridViewTextBoxColumn,
            this.инфраструктураТерриторииDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.домаBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 29);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(644, 150);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // кодДомаDataGridViewTextBoxColumn
            // 
            this.кодДомаDataGridViewTextBoxColumn.DataPropertyName = "Код дома";
            this.кодДомаDataGridViewTextBoxColumn.HeaderText = "Код дома";
            this.кодДомаDataGridViewTextBoxColumn.Name = "кодДомаDataGridViewTextBoxColumn";
            // 
            // типДомаDataGridViewTextBoxColumn
            // 
            this.типДомаDataGridViewTextBoxColumn.DataPropertyName = "Тип дома";
            this.типДомаDataGridViewTextBoxColumn.HeaderText = "Тип дома";
            this.типДомаDataGridViewTextBoxColumn.Name = "типДомаDataGridViewTextBoxColumn";
            // 
            // всегоЭтажейВДомеDataGridViewTextBoxColumn
            // 
            this.всегоЭтажейВДомеDataGridViewTextBoxColumn.DataPropertyName = "Всего этажей в доме";
            this.всегоЭтажейВДомеDataGridViewTextBoxColumn.HeaderText = "Всего этажей в доме";
            this.всегоЭтажейВДомеDataGridViewTextBoxColumn.Name = "всегоЭтажейВДомеDataGridViewTextBoxColumn";
            // 
            // фотографииЗданияDataGridViewImageColumn
            // 
            this.фотографииЗданияDataGridViewImageColumn.DataPropertyName = "Фотографии здания";
            this.фотографииЗданияDataGridViewImageColumn.HeaderText = "Фотографии здания";
            this.фотографииЗданияDataGridViewImageColumn.Name = "фотографииЗданияDataGridViewImageColumn";
            // 
            // районГородаDataGridViewTextBoxColumn
            // 
            this.районГородаDataGridViewTextBoxColumn.DataPropertyName = "Район города";
            this.районГородаDataGridViewTextBoxColumn.HeaderText = "Район города";
            this.районГородаDataGridViewTextBoxColumn.Name = "районГородаDataGridViewTextBoxColumn";
            // 
            // инфраструктураТерриторииDataGridViewTextBoxColumn
            // 
            this.инфраструктураТерриторииDataGridViewTextBoxColumn.DataPropertyName = "Инфраструктура территории";
            this.инфраструктураТерриторииDataGridViewTextBoxColumn.HeaderText = "Инфраструктура территории";
            this.инфраструктураТерриторииDataGridViewTextBoxColumn.Name = "инфраструктураТерриторииDataGridViewTextBoxColumn";
            // 
            // домаBindingSource
            // 
            this.домаBindingSource.DataMember = "Дома";
            this.домаBindingSource.DataSource = this.уП01_ИСПП5_Работягова_ААDataSet;
            // 
            // домаTableAdapter
            // 
            this.домаTableAdapter.ClearBeforeFill = true;
            // 
            // fKДоговорыКвартирыBindingSource
            // 
            this.fKДоговорыКвартирыBindingSource.DataMember = "FK_Договоры_Квартиры";
            this.fKДоговорыКвартирыBindingSource.DataSource = this.квартирыBindingSource;
            // 
            // договорыTableAdapter
            // 
            this.договорыTableAdapter.ClearBeforeFill = true;
            // 
            // fKКвартирыДомаBindingSource
            // 
            this.fKКвартирыДомаBindingSource.DataMember = "FK_Квартиры_Дома";
            this.fKКвартирыДомаBindingSource.DataSource = this.домаBindingSource;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодКвартирыDataGridViewTextBoxColumn,
            this.кодДомаDataGridViewTextBoxColumn1,
            this.документНаПравоСобственностиDataGridViewTextBoxColumn,
            this.наличиеПриватизацииDataGridViewTextBoxColumn,
            this.общаяПлощадьDataGridViewTextBoxColumn,
            this.этажКвартирыDataGridViewTextBoxColumn,
            this.типПланировкиDataGridViewTextBoxColumn,
            this.типСанузлаDataGridViewTextBoxColumn,
            this.адресКвартирыDataGridViewTextBoxColumn,
            this.жилаяПлощадьDataGridViewTextBoxColumn,
            this.площадьКухниDataGridViewTextBoxColumn,
            this.планКвартирыDataGridViewImageColumn});
            this.dataGridView2.DataSource = this.fKКвартирыДомаBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(12, 199);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1243, 150);
            this.dataGridView2.TabIndex = 1;
            // 
            // кодКвартирыDataGridViewTextBoxColumn
            // 
            this.кодКвартирыDataGridViewTextBoxColumn.DataPropertyName = "Код квартиры";
            this.кодКвартирыDataGridViewTextBoxColumn.HeaderText = "Код квартиры";
            this.кодКвартирыDataGridViewTextBoxColumn.Name = "кодКвартирыDataGridViewTextBoxColumn";
            // 
            // кодДомаDataGridViewTextBoxColumn1
            // 
            this.кодДомаDataGridViewTextBoxColumn1.DataPropertyName = "Код дома";
            this.кодДомаDataGridViewTextBoxColumn1.HeaderText = "Код дома";
            this.кодДомаDataGridViewTextBoxColumn1.Name = "кодДомаDataGridViewTextBoxColumn1";
            // 
            // документНаПравоСобственностиDataGridViewTextBoxColumn
            // 
            this.документНаПравоСобственностиDataGridViewTextBoxColumn.DataPropertyName = "Документ на право собственности";
            this.документНаПравоСобственностиDataGridViewTextBoxColumn.HeaderText = "Документ на право собственности";
            this.документНаПравоСобственностиDataGridViewTextBoxColumn.Name = "документНаПравоСобственностиDataGridViewTextBoxColumn";
            // 
            // наличиеПриватизацииDataGridViewTextBoxColumn
            // 
            this.наличиеПриватизацииDataGridViewTextBoxColumn.DataPropertyName = "Наличие приватизации";
            this.наличиеПриватизацииDataGridViewTextBoxColumn.HeaderText = "Наличие приватизации";
            this.наличиеПриватизацииDataGridViewTextBoxColumn.Name = "наличиеПриватизацииDataGridViewTextBoxColumn";
            // 
            // общаяПлощадьDataGridViewTextBoxColumn
            // 
            this.общаяПлощадьDataGridViewTextBoxColumn.DataPropertyName = "Общая площадь";
            this.общаяПлощадьDataGridViewTextBoxColumn.HeaderText = "Общая площадь";
            this.общаяПлощадьDataGridViewTextBoxColumn.Name = "общаяПлощадьDataGridViewTextBoxColumn";
            // 
            // этажКвартирыDataGridViewTextBoxColumn
            // 
            this.этажКвартирыDataGridViewTextBoxColumn.DataPropertyName = "Этаж квартиры";
            this.этажКвартирыDataGridViewTextBoxColumn.HeaderText = "Этаж квартиры";
            this.этажКвартирыDataGridViewTextBoxColumn.Name = "этажКвартирыDataGridViewTextBoxColumn";
            // 
            // типПланировкиDataGridViewTextBoxColumn
            // 
            this.типПланировкиDataGridViewTextBoxColumn.DataPropertyName = "Тип планировки";
            this.типПланировкиDataGridViewTextBoxColumn.HeaderText = "Тип планировки";
            this.типПланировкиDataGridViewTextBoxColumn.Name = "типПланировкиDataGridViewTextBoxColumn";
            // 
            // типСанузлаDataGridViewTextBoxColumn
            // 
            this.типСанузлаDataGridViewTextBoxColumn.DataPropertyName = "Тип санузла";
            this.типСанузлаDataGridViewTextBoxColumn.HeaderText = "Тип санузла";
            this.типСанузлаDataGridViewTextBoxColumn.Name = "типСанузлаDataGridViewTextBoxColumn";
            // 
            // адресКвартирыDataGridViewTextBoxColumn
            // 
            this.адресКвартирыDataGridViewTextBoxColumn.DataPropertyName = "Адрес квартиры";
            this.адресКвартирыDataGridViewTextBoxColumn.HeaderText = "Адрес квартиры";
            this.адресКвартирыDataGridViewTextBoxColumn.Name = "адресКвартирыDataGridViewTextBoxColumn";
            // 
            // жилаяПлощадьDataGridViewTextBoxColumn
            // 
            this.жилаяПлощадьDataGridViewTextBoxColumn.DataPropertyName = "Жилая площадь";
            this.жилаяПлощадьDataGridViewTextBoxColumn.HeaderText = "Жилая площадь";
            this.жилаяПлощадьDataGridViewTextBoxColumn.Name = "жилаяПлощадьDataGridViewTextBoxColumn";
            // 
            // площадьКухниDataGridViewTextBoxColumn
            // 
            this.площадьКухниDataGridViewTextBoxColumn.DataPropertyName = "Площадь кухни";
            this.площадьКухниDataGridViewTextBoxColumn.HeaderText = "Площадь кухни";
            this.площадьКухниDataGridViewTextBoxColumn.Name = "площадьКухниDataGridViewTextBoxColumn";
            // 
            // планКвартирыDataGridViewImageColumn
            // 
            this.планКвартирыDataGridViewImageColumn.DataPropertyName = "План квартиры";
            this.планКвартирыDataGridViewImageColumn.HeaderText = "План квартиры";
            this.планКвартирыDataGridViewImageColumn.Name = "планКвартирыDataGridViewImageColumn";
            // 
            // fKКвартирыДомаBindingSource1
            // 
            this.fKКвартирыДомаBindingSource1.DataMember = "FK_Квартиры_Дома";
            this.fKКвартирыДомаBindingSource1.DataSource = this.домаBindingSource;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(698, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 150);
            this.panel1.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.квартирыBindingSource, "Адрес квартиры", true));
            this.textBox3.Location = new System.Drawing.Point(135, 109);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(148, 20);
            this.textBox3.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.квартирыBindingSource, "Жилая площадь", true));
            this.textBox2.Location = new System.Drawing.Point(135, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(148, 20);
            this.textBox2.TabIndex = 4;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.квартирыBindingSource, "Общая площадь", true));
            this.textBox1.Location = new System.Drawing.Point(135, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(148, 20);
            this.textBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Адрес квартиры";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Жилая площадь";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Общая площадь";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1078, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(173, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Обновить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1078, 156);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(173, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Вернуться в меню";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.BindingSource = this.квартирыBindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.SaveButton,
            this.CancelButton});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1263, 25);
            this.bindingNavigator1.TabIndex = 5;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // SaveButton
            // 
            this.SaveButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SaveButton.Image = ((System.Drawing.Image)(resources.GetObject("SaveButton.Image")));
            this.SaveButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(23, 22);
            this.SaveButton.Text = "Save";
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.CancelButton.Image = ((System.Drawing.Image)(resources.GetObject("CancelButton.Image")));
            this.CancelButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(23, 22);
            this.CancelButton.Text = "Cancel";
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1263, 357);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form7";
            this.Text = "Данные об квартирах";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.уП01_ИСПП5_Работягова_ААDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.квартирыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.домаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKДоговорыКвартирыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKКвартирыДомаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKКвартирыДомаBindingSource1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private УП01_ИСПП5_Работягова_ААDataSet уП01_ИСПП5_Работягова_ААDataSet;
        private System.Windows.Forms.BindingSource квартирыBindingSource;
        private УП01_ИСПП5_Работягова_ААDataSetTableAdapters.КвартирыTableAdapter квартирыTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource домаBindingSource;
        private УП01_ИСПП5_Работягова_ААDataSetTableAdapters.ДомаTableAdapter домаTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодДомаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типДомаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn всегоЭтажейВДомеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn фотографииЗданияDataGridViewImageColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn районГородаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn инфраструктураТерриторииDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource fKДоговорыКвартирыBindingSource;
        private УП01_ИСПП5_Работягова_ААDataSetTableAdapters.ДоговорыTableAdapter договорыTableAdapter;
        private System.Windows.Forms.BindingSource fKКвартирыДомаBindingSource;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодКвартирыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодДомаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn документНаПравоСобственностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn наличиеПриватизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn общаяПлощадьDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn этажКвартирыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типПланировкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типСанузлаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn адресКвартирыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn жилаяПлощадьDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn площадьКухниDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn планКвартирыDataGridViewImageColumn;
        private System.Windows.Forms.BindingSource fKКвартирыДомаBindingSource1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton SaveButton;
        private System.Windows.Forms.ToolStripButton CancelButton;
    }
}