﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class КП : Form
    {
        public КП()
        {
            InitializeComponent();
        }
        int i, index;
        string regist;
        Point Mouse;
        public void registr (string reg)
        {
            regist = reg;
        }
        private void ОформитьКвартиру_Click(object sender, EventArgs e)
        {
            //преход на форму регистрация квартир
            Регистрация_квартир hr = new Регистрация_квартир();
            hr.Show();
            hr.Referral(regist);
        }
        private void tables(int c)
        {
            SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = уП_ПМ_01_Неверов_ДС; Integrated Security = True");
            sqlConnect.Open();
            SqlDataAdapter[] sa = new SqlDataAdapter[5];
            sa[1] = new SqlDataAdapter($"SELECT Client.Registr, [AddressFlat], [PatrolID], [Chief], [Brand], [Document], [DateTime], [False],[Tax], [Compensation] FROM Calling INNER JOIN Contract ON Calling.TreatyID = Contract.TreatyID INNER JOIN Settlement ON Contract.SettlementID = Settlement.SettlementID INNER JOIN Client ON Settlement.Registr = Client.Registr INNER JOIN Flat ON Settlement.FlatID = Flat.FlatID INNER JOIN Capture ON Calling.ActionID = Capture.ActionID  WHERE (Client.Registr = '{regist}') ", sqlConnect);
            sa[2] = new SqlDataAdapter("SELECT [PatrolID], [Chief], [Brand], [Document] FROM [Capture]", sqlConnect);
            sa[3] = new SqlDataAdapter($"SELECT Client.Registr, [AddressFlat], [DateStart], [StopDate], [Cost] FROM Flat INNER JOIN Settlement ON Flat.FlatID = Settlement.FlatID INNER JOIN Client ON Settlement.Registr = Client.Registr INNER JOIN Contract ON Settlement.SettlementID = Contract.SettlementID WHERE (Client.Registr = '{regist}') ", sqlConnect);
            sa[4] = new SqlDataAdapter($"SELECT Client.Registr, [AddressFlat], [Floor], [TypeDoor], [Balcony], [TypeBalcony], [FlatPlan], [Floors], [Key],[TypeHouse] FROM [Flat] INNER JOIN [Flat-House] ON Flat.FlatID = [Flat-House].FlatID INNER JOIN [House] ON [Flat-House].HouseID = House.HouseID INNER JOIN [Settlement] ON Flat.FlatID = Settlement.FlatID INNER JOIN [Client] ON [Settlement].Registr = [Client].Registr WHERE (Client.Registr = '{regist}') ", sqlConnect);
            DataSet ds = new DataSet();
            sa[c].Fill(ds);
            ТаблицыКП.DataSource = ds.Tables[0];
        }
        private void Выйти_Click(object sender, EventArgs e)
        {
            //выход из приложения
            Application.Exit(); 
        }

        private void вернутьсяКАвторизации_Click(object sender, EventArgs e)
        {
            //переход на форму авторизации
            Авторизация av = new Авторизация();
            av.Show();
            Hide();
        }

        private void выйтиИзПриложения_Click(object sender, EventArgs e)
        {
            //выход из приложения
            Application.Exit();
        }

        private void Профиль_Click(object sender, EventArgs e)
        {
            //переход на форму профиль
            Профиль gh = new Профиль();
            gh.Show();
            gh.Index(regist);
        }

        private void ПредыдущаяЗапись_Click(object sender, EventArgs e)
        {
            //переход на предыдущую строку таблицы
            i = ТаблицыКП.RowCount;
            index = ТаблицыКП.CurrentRow.Index;
            if (index <= 0)
            {
                ТаблицыКП.CurrentCell = ТаблицыКП[0, i - 1];
            }
            else
            {
                ТаблицыКП.Rows[index].Selected = true;
                ТаблицыКП.CurrentCell = ТаблицыКП[0, index - 1];
            }
        }

        private void ПерваяЗапись_Click(object sender, EventArgs e)
        {
            //переход на первую строку таблицы
            ТаблицыКП.CurrentCell = ТаблицыКП[0,0];
        }

        private void ПоследняяЗапись_Click(object sender, EventArgs e)
        {
            //переход на последную строку таблицы
            ТаблицыКП.ClearSelection(); //снять выделение всех выбранных ячеек
            index = ТаблицыКП.Rows.Count - 1; // индекс последней строки
            ТаблицыКП.Rows[index].Selected = true; // выделить нужную строку
            ТаблицыКП.CurrentCell = ТаблицыКП[0, index];
        }

        private void КП_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Capture". При необходимости она может быть перемещена или удалена.
            this.captureTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Capture);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Calling". При необходимости она может быть перемещена или удалена.
            this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Calling);
            ТаблицыКП.ReadOnly = true;
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Продление ghj = new Продление();
            ghj.Show();
            ghj.Id(regist);
        }


        private void вызовы_Click(object sender, EventArgs e)
        {
            tables(1);
            ТаблицыКП.ReadOnly = true;
        }

        private void группаЗахвата_Click(object sender, EventArgs e)
        {
            tables(2);
            ТаблицыКП.ReadOnly = true;
        }

        private void ПолеПоиск_TextChanged(object sender, EventArgs e)
        {
            //Поиск
            for (int i = 0; i < ТаблицыКП.RowCount; i++)
            {
                ТаблицыКП.Rows[i].Selected = false;
                for (int j = 0; j < ТаблицыКП.ColumnCount; j++)
                {
                    if (ТаблицыКП.Rows[i].Cells[j].Value != null)
                    {
                        if (ТаблицыКП.Rows[i].Cells[j].Value.ToString().Contains(ПолеПоиск.Text))
                        {
                            ТаблицыКП.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }

        private void договор_Click(object sender, EventArgs e)
        {
            tables(3);
            ТаблицыКП.ReadOnly = true;
        }

        private void квартиры_Click(object sender, EventArgs e)
        {
            tables(4);
            ТаблицыКП.ReadOnly = true;
        }
        
        private void КП_MouseMove(object sender, MouseEventArgs e)
        {
            //передвигает форму по тому как движется мышка по экрану
            if (e.Button == MouseButtons.Left) 
            {
                Left += e.X - Mouse.X;
                Top+= e.Y - Mouse.Y;
            }
        }

        private void КП_MouseDown(object sender, MouseEventArgs e)
        {
            //отпеделяет точку где была эажата клавиша мыши на форме
            Mouse = new Point(e.X, e.Y);
        }

        private void Меню_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click_1(object sender, EventArgs e)
        {
            //следующая строка
            i = ТаблицыКП.RowCount;
            index = ТаблицыКП.CurrentRow.Index;
            if (index >= (i - 1))
            {
                ТаблицыКП.CurrentCell = ТаблицыКП[0, 0];
            }
            else
            {
                ТаблицыКП.Rows[index].Selected = true;
                ТаблицыКП.CurrentCell = ТаблицыКП[0, index + 1];
            }
        }
    }
}
