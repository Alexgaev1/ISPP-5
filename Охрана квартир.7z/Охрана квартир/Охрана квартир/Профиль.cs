﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Профиль : Form
    {
        public Профиль()
        {
            InitializeComponent();
        }
        private object b;int index;
        public void ind (object i)
        {
            i = b;
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Профиль_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            ToolTip tt = new ToolTip();
            tt.SetToolTip(button1, "Нажмите, чтобы подтвердить изменение");
            this.Size = new Size(208, 242);
            index = dataGridView1.CurrentRow.Index;
            if (dataGridView1.Rows[index].Cells[0].Value.ToString().Contains($"{b}"))   
            {
                dataGridView1.Rows[index].Selected = true;
            }
        }
    }
}
