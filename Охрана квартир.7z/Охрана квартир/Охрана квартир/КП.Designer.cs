﻿namespace Охрана_квартир
{
    partial class КП
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(КП));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.вернутьсяКАвторизацииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выйтиИзПриложенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.вызовыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.группаЗахватаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.houseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уППМ01НеверовДСDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.callingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.callingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter();
            this.captureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.captureTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter();
            this.contractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter();
            this.flatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flatTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter();
            this.flatHouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flat_HouseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter();
            this.houseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter();
            this.prolongingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.prolongingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уППМ01НеверовДСDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(776, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 24);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton2,
            this.toolStripButton3,
            this.toolStripButton5,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 32;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.BackColor = System.Drawing.Color.LightGray;
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вернутьсяКАвторизацииToolStripMenuItem,
            this.выйтиИзПриложенияToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(49, 22);
            this.toolStripDropDownButton1.Text = "Файл";
            // 
            // вернутьсяКАвторизацииToolStripMenuItem
            // 
            this.вернутьсяКАвторизацииToolStripMenuItem.Name = "вернутьсяКАвторизацииToolStripMenuItem";
            this.вернутьсяКАвторизацииToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.вернутьсяКАвторизацииToolStripMenuItem.Text = "Вернуться к авторизации";
            this.вернутьсяКАвторизацииToolStripMenuItem.Click += new System.EventHandler(this.вернутьсяКАвторизацииToolStripMenuItem_Click);
            // 
            // выйтиИзПриложенияToolStripMenuItem
            // 
            this.выйтиИзПриложенияToolStripMenuItem.Name = "выйтиИзПриложенияToolStripMenuItem";
            this.выйтиИзПриложенияToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.выйтиИзПриложенияToolStripMenuItem.Text = "Выйти из приложения";
            this.выйтиИзПриложенияToolStripMenuItem.Click += new System.EventHandler(this.выйтиИзПриложенияToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.BackColor = System.Drawing.Color.LightGray;
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вызовыToolStripMenuItem,
            this.группаЗахватаToolStripMenuItem});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton2.Text = "toolStripDropDownButton2";
            // 
            // вызовыToolStripMenuItem
            // 
            this.вызовыToolStripMenuItem.Name = "вызовыToolStripMenuItem";
            this.вызовыToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.вызовыToolStripMenuItem.Text = "Вызовы";
            this.вызовыToolStripMenuItem.Click += new System.EventHandler(this.вызовыToolStripMenuItem_Click);
            // 
            // группаЗахватаToolStripMenuItem
            // 
            this.группаЗахватаToolStripMenuItem.Name = "группаЗахватаToolStripMenuItem";
            this.группаЗахватаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.группаЗахватаToolStripMenuItem.Text = "Группа захвата";
            this.группаЗахватаToolStripMenuItem.Click += new System.EventHandler(this.группаЗахватаToolStripMenuItem_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.BackColor = System.Drawing.Color.LightGray;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(58, 22);
            this.toolStripButton3.Text = "Договор";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.BackColor = System.Drawing.Color.LightGray;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(113, 22);
            this.toolStripButton2.Text = "Продлить договор";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.BackColor = System.Drawing.Color.LightGray;
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(65, 22);
            this.toolStripButton5.Text = "Квартиры";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.BackColor = System.Drawing.Color.LightGray;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(123, 22);
            this.toolStripButton1.Text = "Оформить квартиру";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.BackColor = System.Drawing.Color.LightGray;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Профиль";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.LightGray;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label8.Location = new System.Drawing.Point(522, 1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 22);
            this.label8.TabIndex = 49;
            this.label8.Text = "Поиск:";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.LightGray;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox8.Location = new System.Drawing.Point(572, 1);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.ShortcutsEnabled = false;
            this.textBox8.Size = new System.Drawing.Size(144, 22);
            this.textBox8.TabIndex = 48;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(800, 243);
            this.dataGridView1.TabIndex = 50;
            // 
            // houseBindingSource
            // 
            this.houseBindingSource.DataMember = "House";
            this.houseBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // уППМ01НеверовДСDataSetBindingSource
            // 
            this.уППМ01НеверовДСDataSetBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            this.уППМ01НеверовДСDataSetBindingSource.Position = 0;
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(367, 270);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(35, 35);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 53;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(408, 270);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 35);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 52;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(326, 270);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(449, 270);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 55;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // callingBindingSource
            // 
            this.callingBindingSource.DataMember = "Calling";
            this.callingBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // callingTableAdapter
            // 
            this.callingTableAdapter.ClearBeforeFill = true;
            // 
            // captureBindingSource
            // 
            this.captureBindingSource.DataMember = "Capture";
            this.captureBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // captureTableAdapter
            // 
            this.captureTableAdapter.ClearBeforeFill = true;
            // 
            // contractBindingSource
            // 
            this.contractBindingSource.DataMember = "Contract";
            this.contractBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // contractTableAdapter
            // 
            this.contractTableAdapter.ClearBeforeFill = true;
            // 
            // flatBindingSource
            // 
            this.flatBindingSource.DataMember = "Flat";
            this.flatBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // flatTableAdapter
            // 
            this.flatTableAdapter.ClearBeforeFill = true;
            // 
            // flatHouseBindingSource
            // 
            this.flatHouseBindingSource.DataMember = "Flat-House";
            this.flatHouseBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // flat_HouseTableAdapter
            // 
            this.flat_HouseTableAdapter.ClearBeforeFill = true;
            // 
            // houseTableAdapter
            // 
            this.houseTableAdapter.ClearBeforeFill = true;
            // 
            // prolongingBindingSource
            // 
            this.prolongingBindingSource.DataMember = "Prolonging";
            this.prolongingBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // prolongingTableAdapter
            // 
            this.prolongingTableAdapter.ClearBeforeFill = true;
            // 
            // КП
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(213)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 309);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "КП";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Форма конечного пользователя";
            this.Load += new System.EventHandler(this.КП_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уППМ01НеверовДСDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem вернутьсяКАвторизацииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выйтиИзПриложенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem вызовыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem группаЗахватаToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.BindingSource уППМ01НеверовДСDataSetBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource callingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter callingTableAdapter;
        private System.Windows.Forms.BindingSource captureBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter captureTableAdapter;
        private System.Windows.Forms.BindingSource contractBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter contractTableAdapter;
        private System.Windows.Forms.BindingSource flatBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter flatTableAdapter;
        private System.Windows.Forms.BindingSource flatHouseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter flat_HouseTableAdapter;
        private System.Windows.Forms.BindingSource houseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter houseTableAdapter;
        private System.Windows.Forms.BindingSource prolongingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter prolongingTableAdapter;
    }
}