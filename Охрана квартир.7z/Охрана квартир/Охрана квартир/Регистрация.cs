﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Регистрация : Form
    {
        Point Mouse;
        int index;
        public Регистрация()
        {
            InitializeComponent();
        }
        private void Регистрация_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet1.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter1.Fill(this.уП_ПМ_01_Неверов_ДСDataSet1.Client);
            Надпись.Text = "Введите свои персональные данные";
            this.Size = new Size(325, 375);
            ToolTip tt = new ToolTip();//Данные строки позволяют показывать сплывающую подсказку
            tt.SetToolTip(Выйти, "Нажмите, чтобы закрыть приложение");
            tt.SetToolTip(Вернуться, "Нажмите, чтобы вернуться к форме авторизации");
            for (int i = 0; i < ТаблицаКлиент.RowCount; i++) 
            {
                index = int.Parse(ТаблицаКлиент[0, i].Value.ToString());
            }
        }

        private void Регистрация_MouseMove(object sender, MouseEventArgs e)
        {
            //передвигает форму по тому как движется мышка по экрану
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }

        private void Регистрация_MouseDown(object sender, MouseEventArgs e)
        {
            //отпеделяет точку где была эажата клавиша мыши на форме
            Mouse = new Point(e.X, e.Y);
        }

        private void Зарегистрироваться_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [User]", sqlConnect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Boolean логин = true;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["Логин"].ToString() == ПолеЛогин.Text)
                    {
                        логин = false;
                    }
                }
                if (ПолеФамилия.Text == "" || ПолеИмя.Text == "" || ПолеАдрес.Text == "" || ПолеТелефон.Text == "" || ПолеЛогин.Text == "" || ПолеПароль.Text == "")
                {
                    MessageBox.Show("Введите все данные!");
                }
                else
                {
                    if (логин == false)
                    {
                        MessageBox.Show("Пользователь уже существует!!!");
                    }
                    else
                    {
                        index = index + 1;
                        //создание новых записей в таблицах
                        SqlDataAdapter info1 = new SqlDataAdapter($"INSERT INTO [Client] (Registr,SecondName,FirstName,ThirdName,Address,Phone)VALUES('{index}','{ПолеФамилия.Text}','{ПолеИмя.Text}','{ПолеОтчество.Text}','{ПолеАдрес.Text}','{ПолеТелефон.Text}');", sqlConnect);
                        SqlDataAdapter info2 = new SqlDataAdapter($"INSERT INTO [User] (Registr,Логин,Пароль)VALUES('{index}','{ПолеЛогин.Text}','{ПолеПароль.Text}');", sqlConnect);
                        DataTable dt1 = new DataTable();
                        DataTable dt2 = new DataTable();
                        info1.Fill(dt1);
                        info2.Fill(dt2);
                    }
                    MessageBox.Show($"Пользователь {ПолеИмя.Text} {ПолеФамилия.Text} {ПолеОтчество.Text} зарегестрирован.\nСейчас вас перекинет на форму авторизации, где вам необходимо ввести логин и пароль, который вы вводили.");
                    Авторизация fd = new Авторизация();
                    Hide();
                    fd.Show();
                }
            }
        }

        private void Выйти_Click(object sender, EventArgs e)
        {
            //закрытие приложения
            Application.Exit();
        }

        private void Вернуться_Click(object sender, EventArgs e)
        {
            //переход на форму авторизации
            Авторизация fd = new Авторизация();
            Hide();
            fd.Show();
        }

        private void ПолеФамилия_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеИмя.Focus();
            }
        }

        private void ПолеИмя_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеОтчество.Focus();
            }
        }

        private void ПолеОтчество_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеАдрес.Focus();
            }
        }

        private void ПолеАдрес_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеТелефон.Focus();
            }
        }

        private void ПолеТелефон_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеЛогин.Focus();
            }
        }

        private void ПолеЛогин_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеПароль.Focus();
            }
        }

        private void ПолеПароль_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                Зарегистрироваться.Focus();
            }
        }
    }
}
