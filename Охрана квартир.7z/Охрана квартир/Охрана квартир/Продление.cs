﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Продление : Form
    {
        public Продление()
        {
            InitializeComponent();
        }
        Point Mouse;
        int index;
        string regist;
        private void Продление_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }
        public void Id(string id)
        {
            regist = id;
        }
        private void Продление_MouseDown(object sender, MouseEventArgs e)
        {
            Mouse = new Point(e.X, e.Y);
        }

        private void Продление_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.К1". При необходимости она может быть перемещена или удалена.
            this.к1TableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.К1);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            //this.Size = new Size(275, 400);
            SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = уП_ПМ_01_Неверов_ДС; Integrated Security = True");
            sqlConnect.Open();
            SqlDataAdapter sa = new SqlDataAdapter();
            sa = new SqlDataAdapter($"SELECT Client.Registr, Flat.AddressFlat, Contract.TreatyID, Contract.DateStart, Contract.StopDate FROM Client INNER JOIN Settlement ON Client.Registr = Settlement.Registr INNER JOIN Flat ON Settlement.FlatID = Flat.FlatID INNER JOIN Contract ON Settlement.SettlementID = Contract.SettlementID WHERE(Client.Registr = '{regist}')", sqlConnect);
            DataSet ds = new DataSet();
            sa.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
            for (int i = 0; i < dataGridView2.RowCount; i++)
            {
                index = int.Parse(dataGridView2[0, i].Value.ToString());
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //выход из приложения
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || maskedTextBox1.Text == "" || maskedTextBox2.Text == "" || maskedTextBox3.Text == "")
            {
                MessageBox.Show("Введите все необходимые данные для продления договора!");
            }
            else
            {
                index = index + 1;
                int m;
                using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                {
                    //SqlDataAdapter info1 = new SqlDataAdapter($"INSERT INTO [Prolonging] (ProlongingID,TreaatyID,Prolong,Comment)VALUES('{index}','{m}','{maskedTextBox1.Text}','{textBox1.Text}');", sqlConnect);
                    DataTable dt1 = new DataTable();
                    //info1.Fill(dt1);
                    MessageBox.Show("Ваша заявка на продление договора была принята");
                }
            }  
        }
    }
}
