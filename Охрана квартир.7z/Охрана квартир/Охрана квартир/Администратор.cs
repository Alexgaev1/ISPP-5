﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Охрана_квартир
{
    
    public partial class Администратор : Form
    {
        public Администратор()
        {
            InitializeComponent();
        }
         public int c;
         private Bitmap bmp;
        int i, index,v,g,y;
        private void Form2_Load(object sender, EventArgs e)
        { 

            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.User". При необходимости она может быть перемещена или удалена.
            this.userTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.User);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Calling". При необходимости она может быть перемещена или удалена.
            this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Calling);
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Capture". При необходимости она может быть перемещена или удалена.
            this.captureTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Capture);
            ToolTip tt = new ToolTip();
            tt.SetToolTip(textBox8, "Введите значение, которое хотите найти в таблице");
            tt.SetToolTip(pictureBox3, "Удаление выделенной строки");
            tt.SetToolTip(pictureBox2, "Добавить строку");
            tt.SetToolTip(pictureBox4, "Следующая строка");
            tt.SetToolTip(pictureBox7, "Обновить данные");
            tt.SetToolTip(pictureBox5, "Предыдущая строка");
            tt.SetToolTip(pictureBox1, "Закрыть");
            c = 0;
            table(0);
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label11.Visible = false;
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            groupBox1.Visible = true;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            //dataGridView1.AllowUserToAddRows = false;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            this.Size = new Size(688, 301);
        }
        
        public void a(string b)
        {
            label9.Text = b;
            if (label9.Text == "Админ")
            {
                userToolStripMenuItem.Visible = true;
                toolStripDropDownButton2.Visible = true;
            }
            else
            {
                userToolStripMenuItem.Visible = false;
                toolStripDropDownButton2.Visible = false;
            }
        }
        private void table (int c)
        {
            using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = уП_ПМ_01_Неверов_ДС; Integrated Security = True"))
            {
                switch (c)
                {
                    case 0:
                        dataGridView1.DataSource = clientBindingSource;
                        break;
                    case 1:
                        dataGridView1.DataSource = flatBindingSource;
                        break;
                    case 2:
                        dataGridView1.DataSource = houseBindingSource;
                        break;
                    case 3:
                        dataGridView1.DataSource = flatHouseBindingSource;
                        break;
                    case 4:
                        dataGridView1.DataSource = settlementBindingSource;
                        break;
                    case 5:
                        dataGridView1.DataSource = contractBindingSource;
                        break;
                    case 6:
                        dataGridView1.DataSource = prolongingBindingSource;
                        break;
                    case 7:
                        dataGridView1.DataSource = captureBindingSource;
                        break;
                    case 8:
                        dataGridView1.DataSource = callingBindingSource;
                        break;
                    case 11:
                        dataGridView1.DataSource = userBindingSource;
                        break;

                }
            }

        }
        private void выйтиИзПриложенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 11;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible =true;
            this.Size = new Size(688, 301);
            groupBox10.Location = new Point(567, 26);
            label5.Visible = true;
            label7.Visible = false;
            label6.Visible = false;
            label11.Visible = false;
            comboBox4.Text = label12.Text;
        }

        private void формаГостяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Регистрация us = new Регистрация();
            us.Show();
        }

        private void формаКомандираToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Командир com = new Командир();
            com.ShowDialog();
        }

        private void clientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 0;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = true;
            groupBox1.Location = new Point(567, 26);
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            this.Size = new Size(688, 301);
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = true;
            label6.Visible = true;
            label5.Visible = true;
            label11.Visible = false;
        }

        private void flatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 1;
            table(c);
            label1.Text = dataGridView1.Columns[6].HeaderText;
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            pictureBox1.Location = new Point(839, -1);
            pictureBox6.Visible = true;
            groupBox1.Visible = false;
            groupBox2.Visible = true;
            comboBox1.Visible = false;
            groupBox2.Location = new Point(567, 26);
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = false;
            label11.Visible = false;
            this.Size = new Size(862, 305);
        }

        private void houseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 2;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = true;
            groupBox3.Location = new Point(567, 26);
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label5.Visible = true;
            label7.Visible = false;
            label6.Visible = false;
            label11.Visible = false;
            this.Size = new Size(688, 301);
        }

        private void flatHouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 3;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label7.Visible = false;
            label6.Visible = false;
            label5.Visible = false;
            label11.Visible = false;
            pictureBox1.Location = new Point(664, -1);
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = true;
            groupBox4.Location = new Point(567, 26);
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            pictureBox6.Visible = false;
            this.Size = new Size(688, 301);
        }

        private void settlementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 4;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = true;
            groupBox5.Location = new Point(567, 26);
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = false;
            label6.Visible = false;
            label5.Visible = false;
            label11.Visible = false;
            this.Size = new Size(688, 301);
        }

        private void contractToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 5;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = true;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = true;
            groupBox6.Location = new Point(567, 26);
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = false;
            label6.Visible = true;
            label5.Visible = true;
            label11.Visible = false;
            this.Size = new Size(688, 301);
        }

        private void prolongingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 6;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = true;
            groupBox7.Location = new Point(567, 26);
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label5.Visible = true;
            label7.Visible = false;
            label6.Visible = false;
            label11.Visible = false;
            this.Size = new Size(688, 301);
        }

        private void captureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 7;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = true;
            groupBox8.Location = new Point(567, 26);
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = false;
            label6.Visible = true;
            label5.Visible = true;
            label11.Visible = false;
            this.Size = new Size(688, 301);
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void вернутьсяКАвторизацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Авторизация ав = new Авторизация();
            Hide();
            ав.Show();
        }

        private void выйтиИзПриложенияToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void обновитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            switch (c)
            {
                case 0:clientTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Client); break;
                case 1:flatTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Flat); break;
                case 2:houseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.House);  break;
                case 3:flat_HouseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet._Flat_House);  break;
                case 4:settlementTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Settlement); break;
                case 5:contractTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Contract); break;
                case 6:prolongingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Prolonging); break;
                case 7:captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture);break;
                case 8:callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling);break;
                case 11:userTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.User); break;
            }
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void callingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 8;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            label11.Text = dataGridView1.Columns[6].HeaderText;
            pictureBox1.Location = new Point(664, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = true;
            groupBox9.Location = new Point(567, 26);
            groupBox10.Visible = false;
            label11.Visible = true; 
            label7.Visible = true;
            label6.Visible = true;
            label5.Visible = true;
            label11.Visible = false;
            this.Size = new Size(688, 301);
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            //предыдущая строка
            i = dataGridView1.RowCount;
             index = dataGridView1.CurrentRow.Index;
            if (index<=0)
            {
                dataGridView1.CurrentCell = dataGridView1[0, i-1];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index - 1];
            }
            comboBox4.Text = label12.Text;
        }
        
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            //следующая строка
            i = dataGridView1.RowCount;
            index = dataGridView1.CurrentRow.Index;
            if (index >= (i - 1))
            {
                dataGridView1.CurrentCell = dataGridView1[0,0];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index + 1];
            }
            comboBox4.Text = label12.Text;
        }

        private void dataGridView1_CellStateChanged(object sender, DataGridViewCellStateChangedEventArgs e)
        {
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Добавление строки
            switch (c)
            {
                case 0:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Client] VALUES ('{textBox2.Text}','{textBox3.Text}','{textBox4.Text}','{textBox5.Text}','{textBox6.Text}','{maskedTextBox1.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        maskedTextBox1.Text = "";
                    }
                    break;
                case 1:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Flat] VALUES ('{textBox1.Text}','{textBox7.Text}','{textBox10.Text}','{comboBox2.Text}','{checkBox1.Text}','{comboBox1.Text}','{label10.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        maskedTextBox1.Text = "";
                    }
                    break;
                case 2:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [House] VALUES ('{textBox9.Text}','{textBox11.Text}','{y}','{comboBox3.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox9.Text = "";
                        textBox11.Text = "";
                        checkBox2.Checked = false;
                        comboBox3.Text = "";
                    }
                    break;
                case 3:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Flat-House] VALUES ('{textBox12.Text}','{textBox13.Text}','{textBox14.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox12.Text = "";
                        textBox13.Text = "";
                        textBox14.Text = "";
                    }
                    break;
                case 4:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Settlement] VALUES ('{textBox16.Text}','{textBox17.Text}','{textBox15.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox16.Text = "";
                        textBox17.Text = "";
                        textBox15.Text = "";
                    }
                    break;
                case 5:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Contract] VALUES ('{textBox18.Text}','{textBox19.Text}','{maskedTextBox2.Text}','{maskedTextBox3.Text}','{textBox20.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox18.Text = "";
                        textBox19.Text = "";
                        maskedTextBox2.Text = "";
                        maskedTextBox3.Text = "";
                        textBox20.Text = "";
                    }
                    break;
                case 6:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Prolonging] VALUES ('{textBox22.Text}','{textBox23.Text}','{maskedTextBox4.Text}','{textBox24.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox22.Text = "";
                        textBox23.Text = "";
                        maskedTextBox4.Text = "";
                        textBox24.Text = "";
                    }
                    break;
                case 7:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Capture] VALUES ('{textBox21.Text}','{textBox25.Text}','{textBox27.Text}','{textBox28.Text}','{textBox26.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox21.Text = "";
                        textBox25.Text = "";
                        textBox27.Text = "";
                        textBox28.Text = "";
                        textBox26.Text = "";
                    }
                    break;
                case 8:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Calling] VALUES ('{textBox29.Text}','{textBox30.Text}','{textBox31.Text}','{maskedTextBox5.Text}','{v}','{textBox32.Text}','{textBox33.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox29.Text = "";
                        textBox30.Text = "";
                        textBox31.Text = "";
                        maskedTextBox5.Text = "";
                        checkBox3.Checked = false;
                        textBox32.Text = "";
                        textBox33.Text = "";
                    }
                    break;
                case 11:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [User] VALUES ('{textBox34.Text}','{textBox35.Text}','{comboBox4.Text}','{textBox36.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox34.Text = "";
                        textBox35.Text = "";
                        textBox36.Text = "";
                        comboBox4.Text = "";
                    }
                    break;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //удаление строки
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                if (dataGridView1.Rows[i].Cells[0].Selected == true)
                {
                    dataGridView1.Rows.RemoveAt(i);

                }
            }
        }
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(openFileDialog1.FileName);
                int width = pictureBox6.Width;
                int height = pictureBox6.Height;
                bmp = new Bitmap(image, width, height);
                pictureBox6.Image = bmp;
                label10.Text = openFileDialog1.FileName;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            //Поиск
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox8.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            pictureBox6.ImageLocation = label10.Text;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                g = 1;
                comboBox1.Visible = true;
                label7.Visible = true;
            }
            else if (checkBox1.Checked == false)
            {
                g = 0;
                comboBox1.Visible = false;
                label7.Visible = false;
            }
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        public void label9_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                y = 1;
            }
            else if (checkBox1.Checked == false)
            {
                y = 0;
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            label12.Text = comboBox4.Text;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            label13.Text = comboBox3.Text;
        }
        Point Mouse;
        private void Администратор_MouseDown(object sender, MouseEventArgs e)
        {
            Mouse = new Point(e.X, e.Y);
        }

        private void Администратор_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }
        
        private void pictureBox7_Click(object sender, EventArgs e)
        {
            switch (c)
            {
                case 0: clientTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Client); break;
                case 1: flatTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Flat); break;
                case 2: houseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.House); break;
                case 3: flat_HouseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet._Flat_House); break;
                case 4: settlementTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Settlement); break;
                case 5: contractTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Contract); break;
                case 6: prolongingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Prolonging); break;
                case 7: captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture); break;
                case 8: callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling); break;
                case 11: userTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.User); break;
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            //первая строка
            dataGridView1.CurrentCell = dataGridView1[0, 0];
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            //последняя строка
            dataGridView1.ClearSelection(); //снять выделение всех выбранных ячеек
            index = dataGridView1.Rows.Count - 1; // индекс последней строки
            dataGridView1.Rows[index].Selected = true; // выделить нужную строку
            dataGridView1.CurrentCell = dataGridView1[0, index];
        }
        
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                v = 1;
            }
            else if (checkBox1.Checked == false)
            {
                v = 0;
            }
        }
    }
}
