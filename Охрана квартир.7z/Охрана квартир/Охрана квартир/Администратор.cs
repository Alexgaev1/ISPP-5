﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Охрана_квартир
{
    
    public partial class Администратор : Form
    {
        public Администратор()
        {
            InitializeComponent();
        }
         public int c;
         private Bitmap bmp;
        int i; int index;
        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet5.Capture". При необходимости она может быть перемещена или удалена.
            this.captureTableAdapter1.Fill(this.уП_ПМ_01_Неверов_ДСDataSet5.Capture);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet4.User". При необходимости она может быть перемещена или удалена.
            this.userTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet4.User);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet3.Calling". При необходимости она может быть перемещена или удалена.
            this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet3.Calling);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);

            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            ToolTip tt = new ToolTip();
            tt.SetToolTip(textBox8, "Введите значение, которое хотите найти в таблице");
            tt.SetToolTip(pictureBox3, "Удаление выделенной строки");
            tt.SetToolTip(pictureBox2, "Добавление строки");
            tt.SetToolTip(pictureBox4, "Следующая строка");
            tt.SetToolTip(pictureBox5, "Предыдущая строка");
            tt.SetToolTip(pictureBox1, "Закрыть");
            //dataGridView1.AllowUserToAddRows = false;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            this.Size = new Size(671, 305);
        }
        
        public void table (int c)
        {
            using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
            {
                switch (c)
                {
                    case 0:
                        dataGridView1.DataSource = clientBindingSource;
                        break;
                    case 1:
                        dataGridView1.DataSource = flatBindingSource;
                        break;
                    case 2:
                        dataGridView1.DataSource = houseBindingSource;
                        break;
                    case 3:
                        dataGridView1.DataSource = flatHouseBindingSource;
                        break;
                    case 4:
                        dataGridView1.DataSource = settlementBindingSource;
                        break;
                    case 5:
                        dataGridView1.DataSource = contractBindingSource;
                        break;
                    case 6:
                        dataGridView1.DataSource = prolongingBindingSource;
                        break;
                    case 7:
                        dataGridView1.DataSource = captureBindingSource1;
                        break;
                    case 8:
                        dataGridView1.DataSource = callingBindingSource;
                        break;
                    case 9:
                        dataGridView1.DataSource = userBindingSource;
                        break;
                    case 10:
                        dataGridView1.DataSource = userBindingSource;
                        break;
                    case 11:
                        dataGridView1.DataSource = userBindingSource;
                        break;

                }
            }

        }
        private void выйтиИзПриложенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 11;
            table(c);
            label5.Visible = true;
            textBox5.Visible = true;
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            //label2.Text = dataGridView1.Rows[1].HeaderCell.Value.ToString();
            //label3.Text = dataGridView1.Rows[2].HeaderCell.Value.ToString();
            //label4.Text = dataGridView1.Rows[3].HeaderCell.Value.ToString();
            //label5.Text = dataGridView1.Rows[4].HeaderCell.Value.ToString();

        }

        private void формаГостяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Регистрация us = new Регистрация();
            us.Show();
        }

        private void формаКомандираToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Командир com = new Командир();
            com.ShowDialog();
        }

        private void clientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 0;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            this.Size = new Size(671, 305);
            label7.Visible = true;
            textBox7.Visible = true;
            label6.Visible = true;
            textBox6.Visible = true;
            label5.Visible = true;
            textBox5.Visible = true;
        }

        private void flatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 1;
            table(c);
            label5.Visible = true;
            textBox5.Visible = true;
            pictureBox6.Visible = true;
            label7.Visible = true;
            textBox7.Visible = true;
            label6.Visible = true;
            textBox6.Visible = true;
            pictureBox1.Location = new Point(838, -1);
            this.Size = new Size(862, 305);

        }

        private void houseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 2;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            label5.Visible = true;
            textBox5.Visible = true;
            pictureBox6.Visible = false;
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void flatHouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 3;
            table(c);
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            label5.Visible = false;
            textBox5.Visible = false;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void settlementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 4;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            label5.Visible = false;
            textBox5.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void contractToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 5;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = true;
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = true;
            textBox6.Visible = true;
            label5.Visible = true;
            textBox5.Visible = true;
            this.Size = new Size(671, 305);
        }

        private void prolongingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 6;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            label5.Visible = true;
            textBox5.Visible = true;
            pictureBox6.Visible = false;
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            pictureBox6.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void captureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 7;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            label7.Visible = true;
            textBox7.Visible = true;
            label6.Visible = true;
            textBox6.Visible = true;
            label5.Visible = true;
            textBox5.Visible = true;
            this.Size = new Size(671, 305);
        }

        private void compensationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            label5.Visible = false;
            textBox5.Visible = false;
        }

        private void taxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label7.Visible = false;
            textBox7.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
            label5.Visible = false;
            textBox5.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void вернутьсяКАвторизацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Авторизация ав = new Авторизация();
            Hide();
            ав.Show();
        }

        private void выйтиИзПриложенияToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void обновитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void callingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 8;
            table(c);
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            label7.Visible = true;
            textBox7.Visible = true;
            label6.Visible = true;
            textBox6.Visible = true;
            label5.Visible = true;
            textBox5.Visible = true;
            this.Size = new Size(671, 305);
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            //предыдущая строка
            i = dataGridView1.RowCount;
             index = dataGridView1.CurrentRow.Index;
            if (index<=0)
            {
                dataGridView1.CurrentCell = dataGridView1[0, i-1];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index - 1];
            }
           
        }
        
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            //следующая строка
             i= dataGridView1.RowCount;
            index = dataGridView1.CurrentRow.Index;
            if (index >= (i - 1))
            {
                dataGridView1.CurrentCell = dataGridView1[0, 0];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index + 1];
            }
        }

        private void dataGridView1_CellStateChanged(object sender, DataGridViewCellStateChangedEventArgs e)
        {
            //index = dataGridView1.CurrentRow.Index;
            //textBox2.Text = dataGridView1[1, index].Value.ToString();
            //textBox3.Text = dataGridView1[2, index].Value.ToString();
            //textBox4.Text = dataGridView1[3, index].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Добавление строки

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //удаление строки
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Selected == true)
                    {
                        dataGridView1.Rows.Remove(dataGridView1.Rows[i]);
                    }
                }
            }
        }
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(openFileDialog1.FileName);
                int width = pictureBox6.Width;
                int height = pictureBox6.Height;
                bmp = new Bitmap(image, width, height);
                pictureBox6.Image = bmp;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            //Поиск
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox8.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }
    }
}
