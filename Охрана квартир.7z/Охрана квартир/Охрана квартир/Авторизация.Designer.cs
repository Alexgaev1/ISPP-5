﻿namespace Охрана_квартир
{
    partial class Авторизация
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Авторизация));
            this.Логин = new System.Windows.Forms.Label();
            this.Пароль = new System.Windows.Forms.Label();
            this.ПолеЛогин = new System.Windows.Forms.TextBox();
            this.ПолеПароль = new System.Windows.Forms.TextBox();
            this.Войти = new System.Windows.Forms.Button();
            this.Выйти = new System.Windows.Forms.Button();
            this.Регистрация = new System.Windows.Forms.Button();
            this.Надпись1 = new System.Windows.Forms.Label();
            this.СкрытьПароль = new System.Windows.Forms.PictureBox();
            this.НадписьАвторизация = new System.Windows.Forms.Label();
            this.Закрыть = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.СкрытьПароль)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Закрыть)).BeginInit();
            this.SuspendLayout();
            // 
            // Логин
            // 
            this.Логин.AutoSize = true;
            this.Логин.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Логин.Location = new System.Drawing.Point(13, 80);
            this.Логин.Name = "Логин";
            this.Логин.Size = new System.Drawing.Size(49, 20);
            this.Логин.TabIndex = 1;
            this.Логин.Text = "Логин:";
            // 
            // Пароль
            // 
            this.Пароль.AutoSize = true;
            this.Пароль.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Пароль.Location = new System.Drawing.Point(13, 110);
            this.Пароль.Name = "Пароль";
            this.Пароль.Size = new System.Drawing.Size(60, 20);
            this.Пароль.TabIndex = 2;
            this.Пароль.Text = "Пароль:";
            // 
            // ПолеЛогин
            // 
            this.ПолеЛогин.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЛогин.Location = new System.Drawing.Point(80, 82);
            this.ПолеЛогин.MaxLength = 50;
            this.ПолеЛогин.Name = "ПолеЛогин";
            this.ПолеЛогин.ShortcutsEnabled = false;
            this.ПолеЛогин.Size = new System.Drawing.Size(137, 26);
            this.ПолеЛогин.TabIndex = 3;
            this.ПолеЛогин.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЛогин_KeyPress);
            // 
            // ПолеПароль
            // 
            this.ПолеПароль.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеПароль.Location = new System.Drawing.Point(80, 113);
            this.ПолеПароль.MaxLength = 20;
            this.ПолеПароль.Name = "ПолеПароль";
            this.ПолеПароль.PasswordChar = '*';
            this.ПолеПароль.ShortcutsEnabled = false;
            this.ПолеПароль.Size = new System.Drawing.Size(137, 26);
            this.ПолеПароль.TabIndex = 4;
            this.ПолеПароль.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеПароль_KeyPress);
            // 
            // Войти
            // 
            this.Войти.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Войти.Location = new System.Drawing.Point(17, 176);
            this.Войти.Name = "Войти";
            this.Войти.Size = new System.Drawing.Size(120, 30);
            this.Войти.TabIndex = 6;
            this.Войти.Text = "Войти";
            this.Войти.UseVisualStyleBackColor = true;
            this.Войти.Click += new System.EventHandler(this.Войти_Click);
            // 
            // Выйти
            // 
            this.Выйти.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Выйти.Location = new System.Drawing.Point(17, 212);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(245, 30);
            this.Выйти.TabIndex = 7;
            this.Выйти.Text = "Выйти";
            this.Выйти.UseVisualStyleBackColor = true;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // Регистрация
            // 
            this.Регистрация.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Регистрация.Location = new System.Drawing.Point(142, 176);
            this.Регистрация.Name = "Регистрация";
            this.Регистрация.Size = new System.Drawing.Size(120, 30);
            this.Регистрация.TabIndex = 8;
            this.Регистрация.Text = "Регистрация";
            this.Регистрация.UseVisualStyleBackColor = true;
            this.Регистрация.Click += new System.EventHandler(this.Регистрация_Click);
            // 
            // Надпись1
            // 
            this.Надпись1.AutoEllipsis = true;
            this.Надпись1.AutoSize = true;
            this.Надпись1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись1.Location = new System.Drawing.Point(13, 146);
            this.Надпись1.Name = "Надпись1";
            this.Надпись1.Size = new System.Drawing.Size(0, 20);
            this.Надпись1.TabIndex = 9;
            // 
            // СкрытьПароль
            // 
            this.СкрытьПароль.Image = ((System.Drawing.Image)(resources.GetObject("СкрытьПароль.Image")));
            this.СкрытьПароль.Location = new System.Drawing.Point(232, 113);
            this.СкрытьПароль.Name = "СкрытьПароль";
            this.СкрытьПароль.Size = new System.Drawing.Size(30, 26);
            this.СкрытьПароль.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.СкрытьПароль.TabIndex = 10;
            this.СкрытьПароль.TabStop = false;
            this.СкрытьПароль.Click += new System.EventHandler(this.СкрытьПароль_Click);
            // 
            // НадписьАвторизация
            // 
            this.НадписьАвторизация.AutoSize = true;
            this.НадписьАвторизация.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.НадписьАвторизация.Location = new System.Drawing.Point(38, 27);
            this.НадписьАвторизация.Name = "НадписьАвторизация";
            this.НадписьАвторизация.Size = new System.Drawing.Size(217, 37);
            this.НадписьАвторизация.TabIndex = 11;
            this.НадписьАвторизация.Text = "АВТОРИЗАЦИЯ";
            this.НадписьАвторизация.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Закрыть
            // 
            this.Закрыть.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.Закрыть.Image = ((System.Drawing.Image)(resources.GetObject("Закрыть.Image")));
            this.Закрыть.Location = new System.Drawing.Point(254, 0);
            this.Закрыть.Name = "Закрыть";
            this.Закрыть.Size = new System.Drawing.Size(24, 24);
            this.Закрыть.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Закрыть.TabIndex = 28;
            this.Закрыть.TabStop = false;
            this.Закрыть.Click += new System.EventHandler(this.Закрыть_Click);
            // 
            // Авторизация
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(278, 248);
            this.ControlBox = false;
            this.Controls.Add(this.Закрыть);
            this.Controls.Add(this.НадписьАвторизация);
            this.Controls.Add(this.СкрытьПароль);
            this.Controls.Add(this.Надпись1);
            this.Controls.Add(this.Регистрация);
            this.Controls.Add(this.Выйти);
            this.Controls.Add(this.Войти);
            this.Controls.Add(this.ПолеПароль);
            this.Controls.Add(this.ПолеЛогин);
            this.Controls.Add(this.Пароль);
            this.Controls.Add(this.Логин);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Авторизация";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.Load += new System.EventHandler(this.Авторизация_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Авторизация_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Авторизация_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.СкрытьПароль)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Закрыть)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Логин;
        private System.Windows.Forms.Label Пароль;
        private System.Windows.Forms.TextBox ПолеЛогин;
        private System.Windows.Forms.TextBox ПолеПароль;
        private System.Windows.Forms.Button Войти;
        private System.Windows.Forms.Button Выйти;
        private System.Windows.Forms.Button Регистрация;
        private System.Windows.Forms.Label Надпись1;
        private System.Windows.Forms.PictureBox СкрытьПароль;
        private System.Windows.Forms.Label НадписьАвторизация;
        private System.Windows.Forms.PictureBox Закрыть;
    }
}

