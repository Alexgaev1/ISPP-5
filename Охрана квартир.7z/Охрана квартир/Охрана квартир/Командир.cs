﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Командир : Form
    {
        public Командир()
        {
            InitializeComponent();
        }
        int i, c, index,a;
        private void tab (int c)
        {
            SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = уП_ПМ_01_Неверов_ДС; Integrated Security = True");
            sqlConnect.Open();
            SqlDataAdapter[] sa = new SqlDataAdapter[5];
            sa[1] = new SqlDataAdapter("SELECT [SecondName], [FirstName], [ThirdName], [Address], [Phone], [AddressFlat], [Floor], [TypeDoor], [Balcony], [TypeBalcony], [FlatPlan], [Floors], [Key] FROM [Flat-House] INNER JOIN Flat ON [Flat-House].FlatID = Flat.FlatID INNER JOIN [Settlement] ON Flat.FlatID = Settlement.FlatID INNER JOIN [Client] ON Settlement.Registr = Client.Registr INNER JOIN [House] ON [Flat-House].HouseID = House.HouseID", sqlConnect);
            sa[2] = new SqlDataAdapter("SELECT [SecondName], [FirstName], [ThirdName], [Address], [Phone], [DateStart], [StopDate], [Cost] FROM [Client] INNER JOIN [Settlement] ON Client.Registr = Settlement.Registr INNER JOIN [Contract] ON Settlement.SettlementID = Contract.SettlementID", sqlConnect);
            sa[3] = new SqlDataAdapter("SELECT * from [Calling]", sqlConnect);
            sa[4] = new SqlDataAdapter("SELECT * from [Capture]", sqlConnect);
            DataSet ds = new DataSet();
            sa[c].Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        private void Командир_Load(object sender, EventArgs e)
        {

            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Capture". При необходимости она может быть перемещена или удалена.
            this.captureTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Capture);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Calling". При необходимости она может быть перемещена или удалена.
            this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Calling);
            label6.Visible = false;
            label7.Visible = false;
            label5.Visible = false;
            label4.Visible = false;
            label3.Visible = false;
            label2.Visible = false;
            label1.Visible = false;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox8.Visible = false;
            dataGridView1.Size = new Size(755, 274);
            this.Size = new Size(755, 341);
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            dataGridView1.Size = new Size(755, 274);
            c = 1;
            tab(c);
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            groupBox8.Visible=false;
            groupBox9.Visible=false;
            label1.Visible = false; 
            label2.Visible = false;    
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            dataGridView1.Size = new Size(755, 274);
            c = 2;
            tab(c);
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Авторизация fd = new Авторизация();
            fd.Show();
            Hide();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            dataGridView1.Size = new Size(480, 274);
            c = 4;
            tab(c);
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            label6.Visible = false;
            label7.Visible = false;
            label5.Visible = true;
            label4.Visible = true;
            label3.Visible = true;
            label2.Visible = true;
            label1.Visible = true;
            label1.Text = dataGridView1.Columns[0].HeaderText;
            label2.Text = dataGridView1.Columns[1].HeaderText;
            label3.Text = dataGridView1.Columns[2].HeaderText;
            label4.Text = dataGridView1.Columns[3].HeaderText;
            label5.Text = dataGridView1.Columns[4].HeaderText;
            groupBox9.Visible = false;
            groupBox8.Visible = true;
            groupBox8.Location = new Point(621, 27);
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            dataGridView1.Size = new Size(480, 274);
            c = 3;
            tab(c);
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label5.Visible = true;
            label4.Visible = true;
            label3.Visible = true;
            label2.Visible = true;
            label1.Visible = true;
            label1.Text = dataGridView1.Columns[0].HeaderText;
            label2.Text = dataGridView1.Columns[1].HeaderText;
            label3.Text = dataGridView1.Columns[2].HeaderText;
            label4.Text = dataGridView1.Columns[3].HeaderText;
            label5.Text = dataGridView1.Columns[4].HeaderText;
            label6.Text = dataGridView1.Columns[5].HeaderText;
            label7.Text = dataGridView1.Columns[6].HeaderText;
            groupBox8.Visible = false;
            groupBox9.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //первая строка
            dataGridView1.CurrentCell = dataGridView1[0, 0];
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            //предыдущая строка
            i = dataGridView1.RowCount;
            index = dataGridView1.CurrentRow.Index;
            if (index <= 0)
            {
                dataGridView1.CurrentCell = dataGridView1[0, i - 1];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index - 1];
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            //следующая строка
            i = dataGridView1.RowCount;
            index = dataGridView1.CurrentRow.Index;
            if (index >= (i - 1))
            {
                dataGridView1.CurrentCell = dataGridView1[0, 0];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index + 1];
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            //удаление строки
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Selected == true)
                    {
                        dataGridView1.Rows.Remove(dataGridView1.Rows[i]);
                        switch (c)
                        {
                            case 4: captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture); break;
                            case 3: callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling); break;
                        }

                    }
                }
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            //Добавление строки
            switch (c)
            {
                case 3:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Calling] VALUES ('{textBox2.Text}','{textBox3.Text}','{textBox4.Text}','{maskedTextBox1.Text}','{a}','{textBox5.Text}','{textBox6.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        checkBox1.Checked = false;
                        maskedTextBox1.Text = "";
                    }
                    break;
                case 4:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Capture] VALUES ('{textBox7.Text}','{textBox8.Text}','{textBox9.Text}','{textBox10.Text}','{textBox11.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox7.Text = "";
                        textBox8.Text = "";
                        textBox9.Text = "";
                        textBox10.Text = "";
                        textBox11.Text = "";
                    }
                    break;
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            switch (c)
            {
                case 4: captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture); break;
                case 3: callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling); break;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                a = 1;
            }
            else if (checkBox1.Checked == false)
            {
                a = 0;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //последняя строка
            dataGridView1.ClearSelection(); //снять выделение всех выбранных ячеек
            index = dataGridView1.Rows.Count - 1; // индекс последней строки
            dataGridView1.Rows[index].Selected = true; // выделить нужную строку
            dataGridView1.FirstDisplayedScrollingRowIndex = index; // фокус в нужную строку
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox1.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }
        Point Mouse;
        private void Командир_MouseDown(object sender, MouseEventArgs e)
        {
            Mouse = new Point(e.X, e.Y);
        }

        private void Командир_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }
    }
}
