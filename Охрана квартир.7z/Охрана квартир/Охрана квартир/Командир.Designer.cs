﻿namespace Охрана_квартир
{
    partial class Командир
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Командир));
            this.Выйти = new System.Windows.Forms.PictureBox();
            this.Меню = new System.Windows.Forms.ToolStrip();
            this.Файл = new System.Windows.Forms.ToolStripDropDownButton();
            this.ВернутьсяКАвторизации = new System.Windows.Forms.ToolStripMenuItem();
            this.ВыйтиИзПриложения = new System.Windows.Forms.ToolStripMenuItem();
            this.Клиент = new System.Windows.Forms.ToolStripDropDownButton();
            this.КвартираКлиента = new System.Windows.Forms.ToolStripMenuItem();
            this.Договоры = new System.Windows.Forms.ToolStripMenuItem();
            this.КнопкаВызовы = new System.Windows.Forms.ToolStripButton();
            this.ГруппаЗахвата = new System.Windows.Forms.ToolStripButton();
            this.Поиск = new System.Windows.Forms.Label();
            this.ПолеПоиск = new System.Windows.Forms.TextBox();
            this.ТаблицыКомандир = new System.Windows.Forms.DataGridView();
            this.ПоследняяЗапись = new System.Windows.Forms.PictureBox();
            this.ПерваяЗапись = new System.Windows.Forms.PictureBox();
            this.ПредыдущаяЗапись = new System.Windows.Forms.PictureBox();
            this.СледующаяЗапись = new System.Windows.Forms.PictureBox();
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.callingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.callingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter();
            this.captureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.captureTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter();
            this.contractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter();
            this.flatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flatTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter();
            this.flatHouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flat_HouseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter();
            this.houseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.houseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter();
            this.settlementBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.settlementTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.SettlementTableAdapter();
            this.Надпись1 = new System.Windows.Forms.Label();
            this.Надпись2 = new System.Windows.Forms.Label();
            this.Надпись3 = new System.Windows.Forms.Label();
            this.Надпись4 = new System.Windows.Forms.Label();
            this.Надпись5 = new System.Windows.Forms.Label();
            this.Надпись6 = new System.Windows.Forms.Label();
            this.Надпись7 = new System.Windows.Forms.Label();
            this.Захват = new System.Windows.Forms.GroupBox();
            this.ПолеКодГруппыЗахвата = new System.Windows.Forms.TextBox();
            this.НомерЭкипажа = new System.Windows.Forms.TextBox();
            this.Документ = new System.Windows.Forms.TextBox();
            this.КомандирЭкипажа = new System.Windows.Forms.TextBox();
            this.Автомобиль = new System.Windows.Forms.TextBox();
            this.Вызовы = new System.Windows.Forms.GroupBox();
            this.Компенсация = new System.Windows.Forms.TextBox();
            this.Штраф = new System.Windows.Forms.TextBox();
            this.ДатаВызова = new System.Windows.Forms.MaskedTextBox();
            this.Вызов = new System.Windows.Forms.CheckBox();
            this.CallingID = new System.Windows.Forms.TextBox();
            this.TreatyID = new System.Windows.Forms.TextBox();
            this.ActionID = new System.Windows.Forms.TextBox();
            this.ОбновитьТаблицу = new System.Windows.Forms.PictureBox();
            this.УдалитьЗапись = new System.Windows.Forms.PictureBox();
            this.ДодбавитьЗапись = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).BeginInit();
            this.Меню.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицыКомандир)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПоследняяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПерваяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПредыдущаяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.СледующаяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.settlementBindingSource)).BeginInit();
            this.Захват.SuspendLayout();
            this.Вызовы.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ОбновитьТаблицу)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.УдалитьЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ДодбавитьЗапись)).BeginInit();
            this.SuspendLayout();
            // 
            // Выйти
            // 
            this.Выйти.BackColor = System.Drawing.Color.White;
            this.Выйти.Image = ((System.Drawing.Image)(resources.GetObject("Выйти.Image")));
            this.Выйти.Location = new System.Drawing.Point(731, 0);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(24, 24);
            this.Выйти.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выйти.TabIndex = 31;
            this.Выйти.TabStop = false;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // Меню
            // 
            this.Меню.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Меню.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Файл,
            this.Клиент,
            this.КнопкаВызовы,
            this.ГруппаЗахвата});
            this.Меню.Location = new System.Drawing.Point(0, 0);
            this.Меню.Name = "Меню";
            this.Меню.Size = new System.Drawing.Size(928, 25);
            this.Меню.TabIndex = 32;
            this.Меню.Text = "toolStrip1";
            // 
            // Файл
            // 
            this.Файл.BackColor = System.Drawing.Color.LightGray;
            this.Файл.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Файл.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ВернутьсяКАвторизации,
            this.ВыйтиИзПриложения});
            this.Файл.Image = ((System.Drawing.Image)(resources.GetObject("Файл.Image")));
            this.Файл.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Файл.Name = "Файл";
            this.Файл.Size = new System.Drawing.Size(49, 22);
            this.Файл.Text = "Файл";
            // 
            // ВернутьсяКАвторизации
            // 
            this.ВернутьсяКАвторизации.Name = "ВернутьсяКАвторизации";
            this.ВернутьсяКАвторизации.Size = new System.Drawing.Size(205, 22);
            this.ВернутьсяКАвторизации.Text = "Веруться к авторизации";
            this.ВернутьсяКАвторизации.Click += new System.EventHandler(this.ВернутьсяКАвторизации_Click);
            // 
            // ВыйтиИзПриложения
            // 
            this.ВыйтиИзПриложения.Name = "ВыйтиИзПриложения";
            this.ВыйтиИзПриложения.Size = new System.Drawing.Size(205, 22);
            this.ВыйтиИзПриложения.Text = "Выйти из приложения";
            this.ВыйтиИзПриложения.Click += new System.EventHandler(this.ВыйтиИзПриложения_Click);
            // 
            // Клиент
            // 
            this.Клиент.BackColor = System.Drawing.Color.LightGray;
            this.Клиент.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Клиент.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.КвартираКлиента,
            this.Договоры});
            this.Клиент.Image = ((System.Drawing.Image)(resources.GetObject("Клиент.Image")));
            this.Клиент.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Клиент.Name = "Клиент";
            this.Клиент.Size = new System.Drawing.Size(59, 22);
            this.Клиент.Text = "Клиент";
            // 
            // КвартираКлиента
            // 
            this.КвартираКлиента.Name = "КвартираКлиента";
            this.КвартираКлиента.Size = new System.Drawing.Size(180, 22);
            this.КвартираКлиента.Text = "Квартира клиента";
            this.КвартираКлиента.Click += new System.EventHandler(this.КвартираКлиента_Click);
            // 
            // Договоры
            // 
            this.Договоры.Name = "Договоры";
            this.Договоры.Size = new System.Drawing.Size(180, 22);
            this.Договоры.Text = "Договоры";
            this.Договоры.Click += new System.EventHandler(this.Договоры_Click);
            // 
            // КнопкаВызовы
            // 
            this.КнопкаВызовы.BackColor = System.Drawing.Color.LightGray;
            this.КнопкаВызовы.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.КнопкаВызовы.Image = ((System.Drawing.Image)(resources.GetObject("КнопкаВызовы.Image")));
            this.КнопкаВызовы.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.КнопкаВызовы.Name = "КнопкаВызовы";
            this.КнопкаВызовы.Size = new System.Drawing.Size(54, 22);
            this.КнопкаВызовы.Text = "Вызовы";
            this.КнопкаВызовы.Click += new System.EventHandler(this.Вызовы_Click);
            // 
            // ГруппаЗахвата
            // 
            this.ГруппаЗахвата.BackColor = System.Drawing.Color.LightGray;
            this.ГруппаЗахвата.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ГруппаЗахвата.Image = ((System.Drawing.Image)(resources.GetObject("ГруппаЗахвата.Image")));
            this.ГруппаЗахвата.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ГруппаЗахвата.Name = "ГруппаЗахвата";
            this.ГруппаЗахвата.Size = new System.Drawing.Size(93, 22);
            this.ГруппаЗахвата.Text = "Группа захвата";
            this.ГруппаЗахвата.Click += new System.EventHandler(this.ГруппаЗахвата_Click);
            // 
            // Поиск
            // 
            this.Поиск.BackColor = System.Drawing.Color.LightGray;
            this.Поиск.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Поиск.Location = new System.Drawing.Point(479, 1);
            this.Поиск.Name = "Поиск";
            this.Поиск.Size = new System.Drawing.Size(50, 22);
            this.Поиск.TabIndex = 51;
            this.Поиск.Text = "Поиск:";
            // 
            // ПолеПоиск
            // 
            this.ПолеПоиск.BackColor = System.Drawing.Color.LightGray;
            this.ПолеПоиск.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ПолеПоиск.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ПолеПоиск.Location = new System.Drawing.Point(529, 1);
            this.ПолеПоиск.Multiline = true;
            this.ПолеПоиск.Name = "ПолеПоиск";
            this.ПолеПоиск.ShortcutsEnabled = false;
            this.ПолеПоиск.Size = new System.Drawing.Size(144, 22);
            this.ПолеПоиск.TabIndex = 50;
            this.ПолеПоиск.TextChanged += new System.EventHandler(this.ПолеПоиск_TextChanged);
            // 
            // ТаблицыКомандир
            // 
            this.ТаблицыКомандир.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицыКомандир.Location = new System.Drawing.Point(0, 25);
            this.ТаблицыКомандир.Name = "ТаблицыКомандир";
            this.ТаблицыКомандир.RowHeadersWidth = 51;
            this.ТаблицыКомандир.Size = new System.Drawing.Size(480, 274);
            this.ТаблицыКомандир.TabIndex = 52;
            // 
            // ПоследняяЗапись
            // 
            this.ПоследняяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПоследняяЗапись.Image")));
            this.ПоследняяЗапись.Location = new System.Drawing.Point(423, 305);
            this.ПоследняяЗапись.Name = "ПоследняяЗапись";
            this.ПоследняяЗапись.Size = new System.Drawing.Size(35, 35);
            this.ПоследняяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПоследняяЗапись.TabIndex = 59;
            this.ПоследняяЗапись.TabStop = false;
            this.ПоследняяЗапись.Click += new System.EventHandler(this.ПоследняяЗапись_Click);
            // 
            // ПерваяЗапись
            // 
            this.ПерваяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПерваяЗапись.Image")));
            this.ПерваяЗапись.Location = new System.Drawing.Point(300, 305);
            this.ПерваяЗапись.Name = "ПерваяЗапись";
            this.ПерваяЗапись.Size = new System.Drawing.Size(35, 35);
            this.ПерваяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПерваяЗапись.TabIndex = 58;
            this.ПерваяЗапись.TabStop = false;
            this.ПерваяЗапись.Click += new System.EventHandler(this.ПерваяЗапись_Click);
            // 
            // ПредыдущаяЗапись
            // 
            this.ПредыдущаяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПредыдущаяЗапись.Image")));
            this.ПредыдущаяЗапись.Location = new System.Drawing.Point(341, 305);
            this.ПредыдущаяЗапись.Name = "ПредыдущаяЗапись";
            this.ПредыдущаяЗапись.Size = new System.Drawing.Size(35, 35);
            this.ПредыдущаяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПредыдущаяЗапись.TabIndex = 57;
            this.ПредыдущаяЗапись.TabStop = false;
            this.ПредыдущаяЗапись.Click += new System.EventHandler(this.ПредыдущаяЗапись_Click);
            // 
            // СледующаяЗапись
            // 
            this.СледующаяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("СледующаяЗапись.Image")));
            this.СледующаяЗапись.Location = new System.Drawing.Point(382, 305);
            this.СледующаяЗапись.Name = "СледующаяЗапись";
            this.СледующаяЗапись.Size = new System.Drawing.Size(35, 35);
            this.СледующаяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.СледующаяЗапись.TabIndex = 56;
            this.СледующаяЗапись.TabStop = false;
            this.СледующаяЗапись.Click += new System.EventHandler(this.СледующаяЗапись_Click);
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // callingBindingSource
            // 
            this.callingBindingSource.DataMember = "Calling";
            this.callingBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // callingTableAdapter
            // 
            this.callingTableAdapter.ClearBeforeFill = true;
            // 
            // captureBindingSource
            // 
            this.captureBindingSource.DataMember = "Capture";
            this.captureBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // captureTableAdapter
            // 
            this.captureTableAdapter.ClearBeforeFill = true;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // contractBindingSource
            // 
            this.contractBindingSource.DataMember = "Contract";
            this.contractBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // contractTableAdapter
            // 
            this.contractTableAdapter.ClearBeforeFill = true;
            // 
            // flatBindingSource
            // 
            this.flatBindingSource.DataMember = "Flat";
            this.flatBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // flatTableAdapter
            // 
            this.flatTableAdapter.ClearBeforeFill = true;
            // 
            // flatHouseBindingSource
            // 
            this.flatHouseBindingSource.DataMember = "Flat-House";
            this.flatHouseBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // flat_HouseTableAdapter
            // 
            this.flat_HouseTableAdapter.ClearBeforeFill = true;
            // 
            // houseBindingSource
            // 
            this.houseBindingSource.DataMember = "House";
            this.houseBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // houseTableAdapter
            // 
            this.houseTableAdapter.ClearBeforeFill = true;
            // 
            // settlementBindingSource
            // 
            this.settlementBindingSource.DataMember = "Settlement";
            this.settlementBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // settlementTableAdapter
            // 
            this.settlementTableAdapter.ClearBeforeFill = true;
            // 
            // Надпись1
            // 
            this.Надпись1.AutoSize = true;
            this.Надпись1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись1.Location = new System.Drawing.Point(486, 42);
            this.Надпись1.Name = "Надпись1";
            this.Надпись1.Size = new System.Drawing.Size(13, 20);
            this.Надпись1.TabIndex = 60;
            this.Надпись1.Text = " ";
            // 
            // Надпись2
            // 
            this.Надпись2.AutoSize = true;
            this.Надпись2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись2.Location = new System.Drawing.Point(486, 74);
            this.Надпись2.Name = "Надпись2";
            this.Надпись2.Size = new System.Drawing.Size(13, 20);
            this.Надпись2.TabIndex = 61;
            this.Надпись2.Text = " ";
            // 
            // Надпись3
            // 
            this.Надпись3.AutoSize = true;
            this.Надпись3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись3.Location = new System.Drawing.Point(486, 106);
            this.Надпись3.Name = "Надпись3";
            this.Надпись3.Size = new System.Drawing.Size(13, 20);
            this.Надпись3.TabIndex = 62;
            this.Надпись3.Text = " ";
            // 
            // Надпись4
            // 
            this.Надпись4.AutoSize = true;
            this.Надпись4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись4.Location = new System.Drawing.Point(486, 138);
            this.Надпись4.Name = "Надпись4";
            this.Надпись4.Size = new System.Drawing.Size(13, 20);
            this.Надпись4.TabIndex = 63;
            this.Надпись4.Text = " ";
            // 
            // Надпись5
            // 
            this.Надпись5.AutoSize = true;
            this.Надпись5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись5.Location = new System.Drawing.Point(486, 167);
            this.Надпись5.Name = "Надпись5";
            this.Надпись5.Size = new System.Drawing.Size(13, 20);
            this.Надпись5.TabIndex = 64;
            this.Надпись5.Text = " ";
            // 
            // Надпись6
            // 
            this.Надпись6.AutoSize = true;
            this.Надпись6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись6.Location = new System.Drawing.Point(486, 201);
            this.Надпись6.Name = "Надпись6";
            this.Надпись6.Size = new System.Drawing.Size(13, 20);
            this.Надпись6.TabIndex = 65;
            this.Надпись6.Text = " ";
            // 
            // Надпись7
            // 
            this.Надпись7.AutoSize = true;
            this.Надпись7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись7.Location = new System.Drawing.Point(486, 234);
            this.Надпись7.Name = "Надпись7";
            this.Надпись7.Size = new System.Drawing.Size(13, 20);
            this.Надпись7.TabIndex = 66;
            this.Надпись7.Text = " ";
            // 
            // Захват
            // 
            this.Захват.Controls.Add(this.ПолеКодГруппыЗахвата);
            this.Захват.Controls.Add(this.НомерЭкипажа);
            this.Захват.Controls.Add(this.Документ);
            this.Захват.Controls.Add(this.КомандирЭкипажа);
            this.Захват.Controls.Add(this.Автомобиль);
            this.Захват.Location = new System.Drawing.Point(779, 28);
            this.Захват.Name = "Захват";
            this.Захват.Size = new System.Drawing.Size(123, 235);
            this.Захват.TabIndex = 67;
            this.Захват.TabStop = false;
            // 
            // ПолеКодГруппыЗахвата
            // 
            this.ПолеКодГруппыЗахвата.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "ActionID", true));
            this.ПолеКодГруппыЗахвата.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодГруппыЗахвата.Location = new System.Drawing.Point(6, 12);
            this.ПолеКодГруппыЗахвата.Name = "ПолеКодГруппыЗахвата";
            this.ПолеКодГруппыЗахвата.ShortcutsEnabled = false;
            this.ПолеКодГруппыЗахвата.Size = new System.Drawing.Size(110, 26);
            this.ПолеКодГруппыЗахвата.TabIndex = 51;
            this.ПолеКодГруппыЗахвата.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодГруппыЗахвата_KeyPress);
            // 
            // НомерЭкипажа
            // 
            this.НомерЭкипажа.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "PatrolID", true));
            this.НомерЭкипажа.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.НомерЭкипажа.Location = new System.Drawing.Point(6, 44);
            this.НомерЭкипажа.MaxLength = 4;
            this.НомерЭкипажа.Name = "НомерЭкипажа";
            this.НомерЭкипажа.ShortcutsEnabled = false;
            this.НомерЭкипажа.Size = new System.Drawing.Size(110, 26);
            this.НомерЭкипажа.TabIndex = 52;
            this.НомерЭкипажа.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.НомерЭкипажа_KeyPress);
            // 
            // Документ
            // 
            this.Документ.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "Document", true));
            this.Документ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Документ.Location = new System.Drawing.Point(6, 140);
            this.Документ.MaxLength = 40;
            this.Документ.Name = "Документ";
            this.Документ.ShortcutsEnabled = false;
            this.Документ.Size = new System.Drawing.Size(110, 26);
            this.Документ.TabIndex = 55;
            // 
            // КомандирЭкипажа
            // 
            this.КомандирЭкипажа.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "Chief", true));
            this.КомандирЭкипажа.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.КомандирЭкипажа.Location = new System.Drawing.Point(6, 76);
            this.КомандирЭкипажа.MaxLength = 20;
            this.КомандирЭкипажа.Name = "КомандирЭкипажа";
            this.КомандирЭкипажа.ShortcutsEnabled = false;
            this.КомандирЭкипажа.Size = new System.Drawing.Size(110, 26);
            this.КомандирЭкипажа.TabIndex = 53;
            this.КомандирЭкипажа.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.КомандирЭкипажа_KeyPress);
            // 
            // Автомобиль
            // 
            this.Автомобиль.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "Brand", true));
            this.Автомобиль.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Автомобиль.Location = new System.Drawing.Point(6, 108);
            this.Автомобиль.MaxLength = 15;
            this.Автомобиль.Name = "Автомобиль";
            this.Автомобиль.ShortcutsEnabled = false;
            this.Автомобиль.Size = new System.Drawing.Size(110, 26);
            this.Автомобиль.TabIndex = 54;
            this.Автомобиль.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Автомобиль_KeyPress);
            // 
            // Вызовы
            // 
            this.Вызовы.Controls.Add(this.Компенсация);
            this.Вызовы.Controls.Add(this.Штраф);
            this.Вызовы.Controls.Add(this.ДатаВызова);
            this.Вызовы.Controls.Add(this.Вызов);
            this.Вызовы.Controls.Add(this.CallingID);
            this.Вызовы.Controls.Add(this.TreatyID);
            this.Вызовы.Controls.Add(this.ActionID);
            this.Вызовы.Location = new System.Drawing.Point(621, 27);
            this.Вызовы.Name = "Вызовы";
            this.Вызовы.Size = new System.Drawing.Size(123, 235);
            this.Вызовы.TabIndex = 68;
            this.Вызовы.TabStop = false;
            // 
            // Компенсация
            // 
            this.Компенсация.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "Compensation", true));
            this.Компенсация.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Компенсация.Location = new System.Drawing.Point(6, 204);
            this.Компенсация.MaxLength = 15;
            this.Компенсация.Name = "Компенсация";
            this.Компенсация.ShortcutsEnabled = false;
            this.Компенсация.Size = new System.Drawing.Size(110, 26);
            this.Компенсация.TabIndex = 60;
            // 
            // Штраф
            // 
            this.Штраф.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "Tax", true));
            this.Штраф.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Штраф.Location = new System.Drawing.Point(6, 171);
            this.Штраф.MaxLength = 15;
            this.Штраф.Name = "Штраф";
            this.Штраф.ShortcutsEnabled = false;
            this.Штраф.Size = new System.Drawing.Size(110, 26);
            this.Штраф.TabIndex = 59;
            this.Штраф.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Штраф_KeyPress);
            // 
            // ДатаВызова
            // 
            this.ДатаВызова.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ДатаВызова.BackColor = System.Drawing.SystemColors.Window;
            this.ДатаВызова.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "DateTime", true));
            this.ДатаВызова.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ДатаВызова.Location = new System.Drawing.Point(6, 108);
            this.ДатаВызова.Mask = "00/00/0000";
            this.ДатаВызова.Name = "ДатаВызова";
            this.ДатаВызова.Size = new System.Drawing.Size(110, 26);
            this.ДатаВызова.TabIndex = 58;
            this.ДатаВызова.ValidatingType = typeof(System.DateTime);
            // 
            // Вызов
            // 
            this.Вызов.AutoSize = true;
            this.Вызов.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.callingBindingSource, "False", true));
            this.Вызов.DataBindings.Add(new System.Windows.Forms.Binding("CheckAlign", this.callingBindingSource, "False", true));
            this.Вызов.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.callingBindingSource, "False", true));
            this.Вызов.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Вызов.Location = new System.Drawing.Point(24, 139);
            this.Вызов.Name = "Вызов";
            this.Вызов.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Вызов.Size = new System.Drawing.Size(81, 24);
            this.Вызов.TabIndex = 57;
            this.Вызов.Text = "?Ложный";
            this.Вызов.UseVisualStyleBackColor = true;
            this.Вызов.CheckedChanged += new System.EventHandler(this.Вызов_CheckedChanged);
            // 
            // CallingID
            // 
            this.CallingID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "CallingID", true));
            this.CallingID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CallingID.Location = new System.Drawing.Point(6, 12);
            this.CallingID.Name = "CallingID";
            this.CallingID.ShortcutsEnabled = false;
            this.CallingID.Size = new System.Drawing.Size(110, 26);
            this.CallingID.TabIndex = 51;
            this.CallingID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CallingID_KeyPress);
            // 
            // TreatyID
            // 
            this.TreatyID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "TreatyID", true));
            this.TreatyID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TreatyID.Location = new System.Drawing.Point(6, 44);
            this.TreatyID.Name = "TreatyID";
            this.TreatyID.ShortcutsEnabled = false;
            this.TreatyID.Size = new System.Drawing.Size(110, 26);
            this.TreatyID.TabIndex = 52;
            this.TreatyID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TreatyID_KeyPress);
            // 
            // ActionID
            // 
            this.ActionID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "ActionID", true));
            this.ActionID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ActionID.Location = new System.Drawing.Point(6, 76);
            this.ActionID.Name = "ActionID";
            this.ActionID.ShortcutsEnabled = false;
            this.ActionID.Size = new System.Drawing.Size(110, 26);
            this.ActionID.TabIndex = 53;
            this.ActionID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ActionID_KeyPress);
            // 
            // ОбновитьТаблицу
            // 
            this.ОбновитьТаблицу.Image = ((System.Drawing.Image)(resources.GetObject("ОбновитьТаблицу.Image")));
            this.ОбновитьТаблицу.Location = new System.Drawing.Point(626, 268);
            this.ОбновитьТаблицу.Name = "ОбновитьТаблицу";
            this.ОбновитьТаблицу.Size = new System.Drawing.Size(35, 35);
            this.ОбновитьТаблицу.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ОбновитьТаблицу.TabIndex = 71;
            this.ОбновитьТаблицу.TabStop = false;
            this.ОбновитьТаблицу.Click += new System.EventHandler(this.ОбновитьТаблицу_Click);
            // 
            // УдалитьЗапись
            // 
            this.УдалитьЗапись.Image = ((System.Drawing.Image)(resources.GetObject("УдалитьЗапись.Image")));
            this.УдалитьЗапись.Location = new System.Drawing.Point(708, 268);
            this.УдалитьЗапись.Name = "УдалитьЗапись";
            this.УдалитьЗапись.Size = new System.Drawing.Size(35, 35);
            this.УдалитьЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.УдалитьЗапись.TabIndex = 70;
            this.УдалитьЗапись.TabStop = false;
            this.УдалитьЗапись.Click += new System.EventHandler(this.УдалитьЗапись_Click);
            // 
            // ДодбавитьЗапись
            // 
            this.ДодбавитьЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ДодбавитьЗапись.Image")));
            this.ДодбавитьЗапись.Location = new System.Drawing.Point(667, 268);
            this.ДодбавитьЗапись.Name = "ДодбавитьЗапись";
            this.ДодбавитьЗапись.Size = new System.Drawing.Size(35, 35);
            this.ДодбавитьЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ДодбавитьЗапись.TabIndex = 69;
            this.ДодбавитьЗапись.TabStop = false;
            this.ДодбавитьЗапись.Click += new System.EventHandler(this.ДобавитьЗапись_Click);
            // 
            // Командир
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(928, 341);
            this.Controls.Add(this.ОбновитьТаблицу);
            this.Controls.Add(this.УдалитьЗапись);
            this.Controls.Add(this.ДодбавитьЗапись);
            this.Controls.Add(this.Захват);
            this.Controls.Add(this.Вызовы);
            this.Controls.Add(this.Надпись7);
            this.Controls.Add(this.Надпись6);
            this.Controls.Add(this.Надпись5);
            this.Controls.Add(this.Надпись4);
            this.Controls.Add(this.Надпись3);
            this.Controls.Add(this.Надпись2);
            this.Controls.Add(this.Надпись1);
            this.Controls.Add(this.ПоследняяЗапись);
            this.Controls.Add(this.ПерваяЗапись);
            this.Controls.Add(this.ПредыдущаяЗапись);
            this.Controls.Add(this.СледующаяЗапись);
            this.Controls.Add(this.ТаблицыКомандир);
            this.Controls.Add(this.Поиск);
            this.Controls.Add(this.ПолеПоиск);
            this.Controls.Add(this.Выйти);
            this.Controls.Add(this.Меню);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Командир";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Командир";
            this.Load += new System.EventHandler(this.Командир_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Командир_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Командир_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).EndInit();
            this.Меню.ResumeLayout(false);
            this.Меню.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицыКомандир)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПоследняяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПерваяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПредыдущаяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.СледующаяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.settlementBindingSource)).EndInit();
            this.Захват.ResumeLayout(false);
            this.Захват.PerformLayout();
            this.Вызовы.ResumeLayout(false);
            this.Вызовы.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ОбновитьТаблицу)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.УдалитьЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ДодбавитьЗапись)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Выйти;
        private System.Windows.Forms.ToolStrip Меню;
        private System.Windows.Forms.ToolStripDropDownButton Файл;
        private System.Windows.Forms.ToolStripMenuItem ВернутьсяКАвторизации;
        private System.Windows.Forms.ToolStripMenuItem ВыйтиИзПриложения;
        private System.Windows.Forms.ToolStripDropDownButton Клиент;
        private System.Windows.Forms.ToolStripMenuItem КвартираКлиента;
        private System.Windows.Forms.ToolStripMenuItem Договоры;
        private System.Windows.Forms.ToolStripButton КнопкаВызовы;
        private System.Windows.Forms.ToolStripButton ГруппаЗахвата;
        private System.Windows.Forms.Label Поиск;
        private System.Windows.Forms.TextBox ПолеПоиск;
        private System.Windows.Forms.DataGridView ТаблицыКомандир;
        private System.Windows.Forms.PictureBox ПоследняяЗапись;
        private System.Windows.Forms.PictureBox ПерваяЗапись;
        private System.Windows.Forms.PictureBox ПредыдущаяЗапись;
        private System.Windows.Forms.PictureBox СледующаяЗапись;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource callingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter callingTableAdapter;
        private System.Windows.Forms.BindingSource captureBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter captureTableAdapter;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.BindingSource contractBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter contractTableAdapter;
        private System.Windows.Forms.BindingSource flatBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter flatTableAdapter;
        private System.Windows.Forms.BindingSource flatHouseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter flat_HouseTableAdapter;
        private System.Windows.Forms.BindingSource houseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter houseTableAdapter;
        private System.Windows.Forms.BindingSource settlementBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.SettlementTableAdapter settlementTableAdapter;
        private System.Windows.Forms.Label Надпись1;
        private System.Windows.Forms.Label Надпись2;
        private System.Windows.Forms.Label Надпись3;
        private System.Windows.Forms.Label Надпись4;
        private System.Windows.Forms.Label Надпись5;
        private System.Windows.Forms.Label Надпись6;
        private System.Windows.Forms.Label Надпись7;
        private System.Windows.Forms.GroupBox Захват;
        private System.Windows.Forms.TextBox ПолеКодГруппыЗахвата;
        private System.Windows.Forms.TextBox НомерЭкипажа;
        private System.Windows.Forms.TextBox Документ;
        private System.Windows.Forms.TextBox КомандирЭкипажа;
        private System.Windows.Forms.TextBox Автомобиль;
        private System.Windows.Forms.GroupBox Вызовы;
        private System.Windows.Forms.TextBox Компенсация;
        private System.Windows.Forms.TextBox Штраф;
        private System.Windows.Forms.MaskedTextBox ДатаВызова;
        private System.Windows.Forms.CheckBox Вызов;
        private System.Windows.Forms.TextBox CallingID;
        private System.Windows.Forms.TextBox TreatyID;
        private System.Windows.Forms.TextBox ActionID;
        private System.Windows.Forms.PictureBox ОбновитьТаблицу;
        private System.Windows.Forms.PictureBox УдалитьЗапись;
        private System.Windows.Forms.PictureBox ДодбавитьЗапись;
    }
}