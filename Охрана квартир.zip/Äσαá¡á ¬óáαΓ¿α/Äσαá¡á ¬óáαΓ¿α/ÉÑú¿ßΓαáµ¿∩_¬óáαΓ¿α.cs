﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Регистрация_квартир : Form
    {
        public Регистрация_квартир()
        {
            InitializeComponent();
        }
        Bitmap bmp;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                label12.Visible = true;
                checkBox1.Visible = true;
            }
            else
            {
                label12.Visible = false;
                checkBox1.Visible = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(openFileDialog1.FileName);
                int width = pictureBox1.Width;
                int height = pictureBox1.Height;
                bmp = new Bitmap(image, width, height);
                pictureBox1.Image = bmp;
            }
        }
        private void Регистрация_квартир_Load(object sender, EventArgs e)
        {
            label1.Text = "Шаг 1: Введите данные о квартире";
            ToolTip tt = new ToolTip();
            tt.SetToolTip(pictureBox2, "Закрыть");
            this.Size = new Size(334, 436);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private int a = 1;
        private void page(int a)
        {
            if (a == 1)
            {
                groupBox2.Visible = true;
                groupBox3.Visible = false;
                groupBox1.Visible = false;
                groupBox2.Location = new Point(12, 62);
                label1.Text = "Шаг 1: Введите данные о квартире";
                button1.Text = "Далее";
            }
            if (a == 2)
            {
                groupBox2.Visible = false;
                groupBox3.Visible = true;
                groupBox1.Visible = false;
                groupBox3.Location = new Point(12, 62);
                label1.Text = "Шаг 2: Введите данные о доме, \nв которой находится квартира";
                button1.Text = "Далее";
            }
            if (a == 3)
            {
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox1.Visible= true;
                groupBox1.Location = new Point(12, 62);
                label1.Text = "Шаг 3: Введите время договора";
                button1.Text = "Оформить";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (button1.Text == "Оформить")
            {

            }
            else
            {
                a++;
                page(a);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a--;
            page(a);
            if (a < 1)
            {
                a = 1;
            }
        }

    }
}
