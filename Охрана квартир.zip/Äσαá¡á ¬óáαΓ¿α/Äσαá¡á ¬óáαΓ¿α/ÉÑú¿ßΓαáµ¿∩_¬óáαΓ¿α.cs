﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Регистрация_квартир : Form
    {
        public Регистрация_квартир()
        {
            InitializeComponent();
        }
        Bitmap bmp;
        int check, check1;string ID;
        private int a = 1, n, m, i,j,b;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                check = 1;
                label12.Visible = true;
                comboBox1.Visible = true;
            }
            else if (checkBox1.Checked == false)
            {
                check = 0;
                label12.Visible = false;
                comboBox1.Visible = false;
            }
        }
        public void r(string id)
        {
            ID = id;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(openFileDialog1.FileName);
                int width = pictureBox1.Width;
                int height = pictureBox1.Height;
                bmp = new Bitmap(image, width, height);
                pictureBox1.Image = bmp;
                label3.Text = openFileDialog1.FileName;
            }
        }
        private void Регистрация_квартир_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            label1.Text = "Шаг 1: Введите данные о квартире"+ID;
            ToolTip tt = new ToolTip();
            tt.SetToolTip(pictureBox2, "Закрыть");
            this.Size = new Size(334, 436);
            a = 1;
            page(a);
            checkBox1.Checked = false;
            label12.Visible = false;
            comboBox1.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void page(int a)
        {
            if (a == 1)
            {
                button2.Enabled = false;
                groupBox2.Visible = true;
                groupBox3.Visible = false;
                groupBox1.Visible = false;
                groupBox2.Location = new Point(12, 62);
                label1.Text = "Шаг 1: Введите данные о квартире";
                button1.Text = "Далее";
            }
            if (a == 2)
            {
                button2.Enabled = true;
                groupBox2.Visible = false;
                groupBox3.Visible = true;
                groupBox1.Visible = false;
                groupBox3.Location = new Point(12, 62);
                label1.Text = "Шаг 2: Введите данные о доме, \nв которой находится квартира";
                button1.Text = "Далее";
            }
            if (a == 3)
            {
                button2.Enabled = true;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox1.Visible= true;
                groupBox1.Location = new Point(12, 62);
                label1.Text = "Шаг 3: Введите время договора";
                button1.Text = "Оформить";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Оформить")
            {
                if (textBox8.Text == "" || textBox9.Text == "" || comboBox2.Text == "" || pictureBox1.ImageLocation == "" || comboBox3.Text == "" || textBox15.Text == "" || maskedTextBox1.Text == "" || maskedTextBox4.Text == "")
                {
                }
                else
                { 
                    n = dataGridView1.RowCount;
                    m = dataGridView2.RowCount;
                    i = dataGridView4.RowCount;
                    j = dataGridView3.RowCount;
                    b = dataGridView5.RowCount;
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        try
                        {
                            SqlDataAdapter info1 = new SqlDataAdapter($"INSERT INTO [Flat] (FlatID,AddressFlat,Floor,TypeDoor,Balcony,TypeBalcony,FlatPlan)VALUES('{n}','{textBox8.Text}','{textBox9.Text}','{comboBox2.Text}','{check}','{comboBox1.Text}','{label3.Text}');", sqlConnect);
                            SqlDataAdapter info2 = new SqlDataAdapter($"INSERT INTO [House] (HouseID,Floors,[Key],TypeHouse)VALUES('{m}','{textBox15.Text}','{check1}','{comboBox3.Text}');", sqlConnect);
                            SqlDataAdapter info3 = new SqlDataAdapter($"INSERT INTO [Settlement] (SettlementID,FlatID,Registr)VALUES('{i}','{n}','{ID}');", sqlConnect);
                            SqlDataAdapter info4 = new SqlDataAdapter($"INSERT INTO [Flat-House] ([Flat-HouseID],FlatID,HouseID)VALUES('{b}','{n}','{m}');", sqlConnect);
                            SqlDataAdapter info5 = new SqlDataAdapter($"INSERT INTO [Contract] (TreatyID,SettlementID,DateStart,StopDate,Cost)VALUES('{j}','{i}','{maskedTextBox4.Text}','{maskedTextBox1.Text}','{30000}');", sqlConnect);
                            DataTable dt1 = new DataTable();
                            DataTable dt2 = new DataTable();
                            DataTable dt3 = new DataTable();
                            DataTable dt4 = new DataTable();
                            DataTable dt5 = new DataTable();
                            info1.Fill(dt1);
                            info2.Fill(dt2);
                            info3.Fill(dt3);
                            info4.Fill(dt4);
                            info5.Fill(dt5);
                        }
                        catch { }
                    }
                }
                MessageBox.Show("Квартира была оформленна");
            }
            else
            {
                a++;
                page(a);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a--;
            page(a);
            if (a < 1)
            {
                a = 1;
            }
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        Point Mouse;

        private void Регистрация_квартир_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }

        private void Регистрация_квартир_MouseDown(object sender, MouseEventArgs e)
        {
            Mouse = new Point(e.X, e.Y);
        }
        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void checkBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                check1 = 1;
            }
            else if (checkBox1.Checked == false)
            {
                check1 = 0;
            }
        }
    }
}
