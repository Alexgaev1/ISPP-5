﻿namespace Охрана_квартир
{
    partial class Профиль
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Профиль));
            this.Фамилия = new System.Windows.Forms.Label();
            this.Имя = new System.Windows.Forms.Label();
            this.Отчество = new System.Windows.Forms.Label();
            this.Адрес = new System.Windows.Forms.Label();
            this.Телефон = new System.Windows.Forms.Label();
            this.ПолеФамилия = new System.Windows.Forms.TextBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.ПолеИмя = new System.Windows.Forms.TextBox();
            this.ПолеОтчество = new System.Windows.Forms.TextBox();
            this.ПолеАдрес = new System.Windows.Forms.TextBox();
            this.Выйти = new System.Windows.Forms.PictureBox();
            this.Обновить = new System.Windows.Forms.Button();
            this.ПолеТелефон = new System.Windows.Forms.MaskedTextBox();
            this.ТаблицаКлиент = new System.Windows.Forms.DataGridView();
            this.registrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.secondNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thirdNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаКлиент)).BeginInit();
            this.SuspendLayout();
            // 
            // Фамилия
            // 
            this.Фамилия.AutoSize = true;
            this.Фамилия.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Фамилия.Location = new System.Drawing.Point(16, 46);
            this.Фамилия.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Фамилия.Name = "Фамилия";
            this.Фамилия.Size = new System.Drawing.Size(109, 25);
            this.Фамилия.TabIndex = 0;
            this.Фамилия.Text = "Фамилия:";
            // 
            // Имя
            // 
            this.Имя.AutoSize = true;
            this.Имя.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Имя.Location = new System.Drawing.Point(16, 87);
            this.Имя.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Имя.Name = "Имя";
            this.Имя.Size = new System.Drawing.Size(60, 25);
            this.Имя.TabIndex = 1;
            this.Имя.Text = "Имя:";
            // 
            // Отчество
            // 
            this.Отчество.AutoSize = true;
            this.Отчество.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Отчество.Location = new System.Drawing.Point(16, 129);
            this.Отчество.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Отчество.Name = "Отчество";
            this.Отчество.Size = new System.Drawing.Size(110, 25);
            this.Отчество.TabIndex = 2;
            this.Отчество.Text = "Отчество:";
            // 
            // Адрес
            // 
            this.Адрес.AutoSize = true;
            this.Адрес.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Адрес.Location = new System.Drawing.Point(16, 171);
            this.Адрес.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Адрес.Name = "Адрес";
            this.Адрес.Size = new System.Drawing.Size(75, 25);
            this.Адрес.TabIndex = 3;
            this.Адрес.Text = "Адрес:";
            // 
            // Телефон
            // 
            this.Телефон.AutoSize = true;
            this.Телефон.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Телефон.Location = new System.Drawing.Point(16, 214);
            this.Телефон.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Телефон.Name = "Телефон";
            this.Телефон.Size = new System.Drawing.Size(105, 25);
            this.Телефон.TabIndex = 4;
            this.Телефон.Text = "Телефон:";
            // 
            // ПолеФамилия
            // 
            this.ПолеФамилия.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "SecondName", true));
            this.ПолеФамилия.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеФамилия.Location = new System.Drawing.Point(140, 42);
            this.ПолеФамилия.Margin = new System.Windows.Forms.Padding(4);
            this.ПолеФамилия.MaxLength = 60;
            this.ПолеФамилия.Name = "ПолеФамилия";
            this.ПолеФамилия.ShortcutsEnabled = false;
            this.ПолеФамилия.Size = new System.Drawing.Size(132, 30);
            this.ПолеФамилия.TabIndex = 6;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ПолеИмя
            // 
            this.ПолеИмя.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "FirstName", true));
            this.ПолеИмя.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеИмя.Location = new System.Drawing.Point(140, 84);
            this.ПолеИмя.Margin = new System.Windows.Forms.Padding(4);
            this.ПолеИмя.MaxLength = 60;
            this.ПолеИмя.Name = "ПолеИмя";
            this.ПолеИмя.ShortcutsEnabled = false;
            this.ПолеИмя.Size = new System.Drawing.Size(132, 30);
            this.ПолеИмя.TabIndex = 7;
            // 
            // ПолеОтчество
            // 
            this.ПолеОтчество.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "ThirdName", true));
            this.ПолеОтчество.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеОтчество.Location = new System.Drawing.Point(140, 126);
            this.ПолеОтчество.Margin = new System.Windows.Forms.Padding(4);
            this.ПолеОтчество.MaxLength = 60;
            this.ПолеОтчество.Name = "ПолеОтчество";
            this.ПолеОтчество.ShortcutsEnabled = false;
            this.ПолеОтчество.Size = new System.Drawing.Size(132, 30);
            this.ПолеОтчество.TabIndex = 8;
            // 
            // ПолеАдрес
            // 
            this.ПолеАдрес.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Address", true));
            this.ПолеАдрес.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеАдрес.Location = new System.Drawing.Point(140, 167);
            this.ПолеАдрес.Margin = new System.Windows.Forms.Padding(4);
            this.ПолеАдрес.MaxLength = 60;
            this.ПолеАдрес.Name = "ПолеАдрес";
            this.ПолеАдрес.ShortcutsEnabled = false;
            this.ПолеАдрес.Size = new System.Drawing.Size(132, 30);
            this.ПолеАдрес.TabIndex = 9;
            // 
            // Выйти
            // 
            this.Выйти.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.Выйти.Image = ((System.Drawing.Image)(resources.GetObject("Выйти.Image")));
            this.Выйти.Location = new System.Drawing.Point(245, 0);
            this.Выйти.Margin = new System.Windows.Forms.Padding(4);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(32, 30);
            this.Выйти.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выйти.TabIndex = 29;
            this.Выйти.TabStop = false;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // Обновить
            // 
            this.Обновить.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Обновить.Location = new System.Drawing.Point(81, 250);
            this.Обновить.Margin = new System.Windows.Forms.Padding(4);
            this.Обновить.Name = "Обновить";
            this.Обновить.Size = new System.Drawing.Size(132, 37);
            this.Обновить.TabIndex = 30;
            this.Обновить.Text = "Обновить";
            this.Обновить.UseVisualStyleBackColor = true;
            this.Обновить.Click += new System.EventHandler(this.Обновить_Click);
            // 
            // ПолеТелефон
            // 
            this.ПолеТелефон.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Phone", true));
            this.ПолеТелефон.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеТелефон.Location = new System.Drawing.Point(140, 210);
            this.ПолеТелефон.Margin = new System.Windows.Forms.Padding(4);
            this.ПолеТелефон.Mask = "9990000000";
            this.ПолеТелефон.Name = "ПолеТелефон";
            this.ПолеТелефон.ShortcutsEnabled = false;
            this.ПолеТелефон.Size = new System.Drawing.Size(132, 30);
            this.ПолеТелефон.TabIndex = 31;
            // 
            // ТаблицаКлиент
            // 
            this.ТаблицаКлиент.AutoGenerateColumns = false;
            this.ТаблицаКлиент.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаКлиент.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.registrDataGridViewTextBoxColumn,
            this.secondNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.thirdNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn});
            this.ТаблицаКлиент.DataSource = this.clientBindingSource;
            this.ТаблицаКлиент.Location = new System.Drawing.Point(300, 27);
            this.ТаблицаКлиент.Margin = new System.Windows.Forms.Padding(4);
            this.ТаблицаКлиент.Name = "ТаблицаКлиент";
            this.ТаблицаКлиент.RowHeadersWidth = 51;
            this.ТаблицаКлиент.Size = new System.Drawing.Size(891, 185);
            this.ТаблицаКлиент.TabIndex = 32;
            // 
            // registrDataGridViewTextBoxColumn
            // 
            this.registrDataGridViewTextBoxColumn.DataPropertyName = "Registr";
            this.registrDataGridViewTextBoxColumn.HeaderText = "Registr";
            this.registrDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.registrDataGridViewTextBoxColumn.Name = "registrDataGridViewTextBoxColumn";
            this.registrDataGridViewTextBoxColumn.Width = 125;
            // 
            // secondNameDataGridViewTextBoxColumn
            // 
            this.secondNameDataGridViewTextBoxColumn.DataPropertyName = "SecondName";
            this.secondNameDataGridViewTextBoxColumn.HeaderText = "SecondName";
            this.secondNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.secondNameDataGridViewTextBoxColumn.Name = "secondNameDataGridViewTextBoxColumn";
            this.secondNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // thirdNameDataGridViewTextBoxColumn
            // 
            this.thirdNameDataGridViewTextBoxColumn.DataPropertyName = "ThirdName";
            this.thirdNameDataGridViewTextBoxColumn.HeaderText = "ThirdName";
            this.thirdNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.thirdNameDataGridViewTextBoxColumn.Name = "thirdNameDataGridViewTextBoxColumn";
            this.thirdNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            this.phoneDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.Width = 125;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // Профиль
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(1205, 298);
            this.Controls.Add(this.ТаблицаКлиент);
            this.Controls.Add(this.ПолеТелефон);
            this.Controls.Add(this.Обновить);
            this.Controls.Add(this.Выйти);
            this.Controls.Add(this.ПолеАдрес);
            this.Controls.Add(this.ПолеОтчество);
            this.Controls.Add(this.ПолеИмя);
            this.Controls.Add(this.ПолеФамилия);
            this.Controls.Add(this.Телефон);
            this.Controls.Add(this.Адрес);
            this.Controls.Add(this.Отчество);
            this.Controls.Add(this.Имя);
            this.Controls.Add(this.Фамилия);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Профиль";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Профиль";
            this.Load += new System.EventHandler(this.Профиль_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Профиль_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Профиль_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаКлиент)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Фамилия;
        private System.Windows.Forms.Label Имя;
        private System.Windows.Forms.Label Отчество;
        private System.Windows.Forms.Label Адрес;
        private System.Windows.Forms.Label Телефон;
        private System.Windows.Forms.TextBox ПолеФамилия;
        private System.Windows.Forms.TextBox ПолеИмя;
        private System.Windows.Forms.TextBox ПолеОтчество;
        private System.Windows.Forms.TextBox ПолеАдрес;
        private System.Windows.Forms.PictureBox Выйти;
        private System.Windows.Forms.Button Обновить;
        private System.Windows.Forms.MaskedTextBox ПолеТелефон;
        private System.Windows.Forms.DataGridView ТаблицаКлиент;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn registrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn secondNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn thirdNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
    }
}