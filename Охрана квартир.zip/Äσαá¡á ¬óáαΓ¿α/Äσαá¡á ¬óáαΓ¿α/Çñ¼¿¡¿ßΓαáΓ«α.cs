﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Охрана_квартир
{
    
    public partial class Администратор : Form
    {
        public Администратор()
        {
            InitializeComponent();
        }
         public int c;
         private Bitmap bmp;
        int i; int index;
        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_НеверовDataSet.User". При необходимости она может быть перемещена или удалена.
            this.userTableAdapter1.Fill(this.уП_НеверовDataSet.User);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_НеверовDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter1.Fill(this.уП_НеверовDataSet.Client);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.User". При необходимости она может быть перемещена или удалена.
            //this.userTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.User);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Capture". При необходимости она может быть перемещена или удалена.
            //this.captureTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Capture);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Calling". При необходимости она может быть перемещена или удалена.
            //this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Calling);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            //this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            //this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            //this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            //this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            //this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            //this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            //// TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            //this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            ToolTip tt = new ToolTip();
            tt.SetToolTip(textBox8, "Введите значение, которое хотите найти в таблице");
            tt.SetToolTip(pictureBox3, "Удаление выделенной строки");
            tt.SetToolTip(pictureBox2, "Добавить строку");
            tt.SetToolTip(pictureBox4, "Следующая строка");
            tt.SetToolTip(pictureBox7, "Обновить данные");
            tt.SetToolTip(pictureBox5, "Предыдущая строка");
            tt.SetToolTip(pictureBox1, "Закрыть");
            c = 0;
            table(0);
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            groupBox1.Visible = true;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            //dataGridView1.AllowUserToAddRows = false;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            this.Size = new Size(671, 305);
           
            
        }
        
        public void a(string b)
        {
            label9.Text = b;
            if (label9.Text == "Админ")
            {
                userToolStripMenuItem.Visible = true;
                toolStripDropDownButton2.Visible = true;
            }
            else
            {
                userToolStripMenuItem.Visible = false;
                toolStripDropDownButton2.Visible = false;
            }
        }
        public void table (int c)
        {
            using (SqlConnection sqlConnect = new SqlConnection("Data Source=DESKTOP-6Q0NJ7O;Initial Catalog = УП_Неверов; Integrated Security = True"))
            {
                switch (c)
                {
                    case 0:
                        dataGridView1.DataSource = clientBindingSource1;
                        break;
                    //case 1:
                    //    dataGridView1.DataSource = flatBindingSource;
                    //    break;
                    //case 2:
                    //    dataGridView1.DataSource = houseBindingSource;
                    //    break;
                    //case 3:
                    //    dataGridView1.DataSource = flatHouseBindingSource;
                    //    break;
                    //case 4:
                    //    dataGridView1.DataSource = settlementBindingSource;
                    //    break;
                    //case 5:
                    //    dataGridView1.DataSource = contractBindingSource;
                    //    break;
                    //case 6:
                    //    dataGridView1.DataSource = prolongingBindingSource;
                    //    break;
                    //case 7:
                    //    dataGridView1.DataSource = captureBindingSource;
                    //    break;
                    //case 8:
                    //    dataGridView1.DataSource = callingBindingSource;
                    //    break;
                    case 11:
                        dataGridView1.DataSource = userBindingSource1;
                        break;

                }
            }

        }
        private void выйтиИзПриложенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 11;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible =true;
            groupBox10.Location = new Point(548, 26);
            label5.Visible = true;
            label7.Visible = false;
            label6.Visible = false;
        }

        private void формаГостяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Регистрация us = new Регистрация();
            us.Show();
        }

        private void формаКомандираToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Командир com = new Командир();
            com.ShowDialog();
        }

        private void clientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 0;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = true;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            this.Size = new Size(671, 305);
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = true;
            label6.Visible = true;
            label5.Visible = true;
        }

        private void flatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 1;
            table(c);
            label1.Text = dataGridView1.Columns[6].HeaderText;
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            pictureBox1.Location = new Point(838, -1);
            pictureBox6.Visible = true;
            groupBox1.Visible = false;
            groupBox2.Visible = true;
            comboBox1.Visible = false;
            groupBox2.Location = new Point(548, 26);
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = false;
            this.Size = new Size(862, 305);
        }

        private void houseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 2;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = true;
            groupBox3.Location = new Point(548, 26);
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label5.Visible = true;
            label7.Visible = false;
            label6.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void flatHouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 3;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label7.Visible = false;
            label6.Visible = false;
            label5.Visible = false;
            pictureBox1.Location = new Point(647, -1);
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = true;
            groupBox4.Location = new Point(548, 26);
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            pictureBox6.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void settlementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 4;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = true;
            groupBox5.Location = new Point(548, 26);
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = false;
            label6.Visible = false;
            label5.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void contractToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 5;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = true;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = true;
            groupBox6.Location = new Point(548, 26);
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = false;
            label6.Visible = true;
            label5.Visible = true;
            this.Size = new Size(671, 305);
        }

        private void prolongingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 6;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = true;
            groupBox7.Location = new Point(548, 26);
            groupBox8.Visible = false;
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label5.Visible = true;
            label7.Visible = false;
            label6.Visible = false;
            this.Size = new Size(671, 305);
        }

        private void captureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 7;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = true;
            groupBox8.Location = new Point(548, 26);
            groupBox9.Visible = false;
            groupBox10.Visible = false;
            label7.Visible = false;
            label6.Visible = true;
            label5.Visible = true;
            this.Size = new Size(671, 305);
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void вернутьсяКАвторизацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Авторизация ав = new Авторизация();
            Hide();
            ав.Show();
        }

        private void выйтиИзПриложенияToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void обновитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            switch (c)
            {
                case 0:
                    
                    clientTableAdapter1.Update(уП_НеверовDataSet.Client);
                    break;
                case 1:
                    
                    break;
                case 2:
                    
                    break;
                case 3:
                    
                    break;
                case 4:
                    
                    break;
                case 5:
                    
                    break;
                case 6:
                    
                    break;
                case 7:
                    
                    break;
                case 8:
                    
                    break;
                case 9:
                   
                    break;
                case 10:
                    
                    break;
                case 11:
                    userTableAdapter1.Update(уП_НеверовDataSet.User);
                    break;
            }
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void callingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            c = 8;
            table(c);
            label2.Text = dataGridView1.Columns[0].HeaderText;
            label3.Text = dataGridView1.Columns[1].HeaderText;
            label4.Text = dataGridView1.Columns[2].HeaderText;
            label5.Text = dataGridView1.Columns[3].HeaderText;
            label6.Text = dataGridView1.Columns[4].HeaderText;
            label7.Text = dataGridView1.Columns[5].HeaderText;
            pictureBox1.Location = new Point(647, -1);
            pictureBox6.Visible = false;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            groupBox6.Visible = false;
            groupBox7.Visible = false;
            groupBox8.Visible = false;
            groupBox9.Visible = true;
            groupBox9.Location = new Point(548, 26);
            groupBox10.Visible = false;

            label7.Visible = true;
            label6.Visible = true;
            label5.Visible = true;
            this.Size = new Size(671, 305);
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            //предыдущая строка
            i = dataGridView1.RowCount;
             index = dataGridView1.CurrentRow.Index;
            if (index<=0)
            {
                dataGridView1.CurrentCell = dataGridView1[0, i-1];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index - 1];
            }
           
        }
        
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            
            //следующая строка
            i = dataGridView1.RowCount;
            index = dataGridView1.CurrentRow.Index;
            if (index >= (i - 1))
            {
                dataGridView1.CurrentCell = dataGridView1[0,0];
            }
            else
            {
                dataGridView1.Rows[index].Selected = true;
                dataGridView1.CurrentCell = dataGridView1[0, index + 1];
            }
            
        }

        private void dataGridView1_CellStateChanged(object sender, DataGridViewCellStateChangedEventArgs e)
        {
            //index = dataGridView1.CurrentRow.Index;
            //textBox2.Text = dataGridView1[1, index].Value.ToString();
            //textBox3.Text = dataGridView1[2, index].Value.ToString();
            //textBox4.Text = dataGridView1[3, index].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Добавление строки
            switch (c)
            {
                case 0:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=DESKTOP-6Q0NJ7O;Initial Catalog = УП_Неверов; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da =  new SqlDataAdapter($"INSERT INTO Client VALUES ('{textBox2.Text}','{textBox3.Text}','{textBox4.Text}','{textBox5.Text}','{textBox6.Text}','{maskedTextBox1.Text}');", sqlConnect);
                        da.Fill(dt);
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        maskedTextBox1.Text = "";
                    }
                    break;
                case 1:

                    break;
                case 2:

                    break;
                case 3:

                    break;
                case 4:

                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:

                    break;
                case 9:

                    break;
                case 10:

                    break;
                case 11:
                    userTableAdapter1.Update(уП_НеверовDataSet.User);
                    break;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //удаление строки
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Selected == true)
                    {
                        dataGridView1.Rows.Remove(dataGridView1.Rows[i]);
                        switch (c)
                        {
                            case 11:
                                userTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.User);
                                break;
                        }
                        
                    }
                }
            }
        }
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(openFileDialog1.FileName);
                int width = pictureBox6.Width;
                int height = pictureBox6.Height;
                bmp = new Bitmap(image, width, height);
                pictureBox6.Image = bmp;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            //Поиск
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox8.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                comboBox1.Visible = false;
                label7.Visible = false;
            }
            else if (checkBox1.Checked == true)
            {
                comboBox1.Visible = true;
                label7.Visible = true;
            }
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        public void label9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            switch (c)
            {
                case 0:

                    clientTableAdapter1.Update(уП_НеверовDataSet.Client);
                    break;
                case 1:

                    break;
                case 2:

                    break;
                case 3:

                    break;
                case 4:

                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:

                    break;
                case 9:

                    break;
                case 10:

                    break;
                case 11:
                    userTableAdapter1.Update(уП_НеверовDataSet.User);
                    break;
            }
        }
    }
}
