﻿namespace Охрана_квартир
{
    partial class КП
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(КП));
            this.Выйти = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Файл = new System.Windows.Forms.ToolStripDropDownButton();
            this.вернутьсяКАвторизации = new System.Windows.Forms.ToolStripMenuItem();
            this.выйтиИзПриложения = new System.Windows.Forms.ToolStripMenuItem();
            this.Меню = new System.Windows.Forms.ToolStripDropDownButton();
            this.вызовы = new System.Windows.Forms.ToolStripMenuItem();
            this.группаЗахвата = new System.Windows.Forms.ToolStripMenuItem();
            this.договор = new System.Windows.Forms.ToolStripMenuItem();
            this.квартиры = new System.Windows.Forms.ToolStripMenuItem();
            this.ПродлитьДоговор = new System.Windows.Forms.ToolStripButton();
            this.ОформитьКвартиру = new System.Windows.Forms.ToolStripButton();
            this.Профиль = new System.Windows.Forms.ToolStripButton();
            this.Поиск = new System.Windows.Forms.Label();
            this.ПолеПоиск = new System.Windows.Forms.TextBox();
            this.ТаблицыКП = new System.Windows.Forms.DataGridView();
            this.houseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уППМ01НеверовДСDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.ПредыдущаяЗапись = new System.Windows.Forms.PictureBox();
            this.СледующаяЗапись = new System.Windows.Forms.PictureBox();
            this.ПерваяЗапись = new System.Windows.Forms.PictureBox();
            this.ПоследняяЗапись = new System.Windows.Forms.PictureBox();
            this.callingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.callingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter();
            this.captureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.captureTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter();
            this.contractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter();
            this.flatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flatTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter();
            this.flatHouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flat_HouseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter();
            this.houseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter();
            this.prolongingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.prolongingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицыКП)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уППМ01НеверовДСDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПредыдущаяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.СледующаяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПерваяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПоследняяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Выйти
            // 
            this.Выйти.BackColor = System.Drawing.Color.White;
            this.Выйти.Image = ((System.Drawing.Image)(resources.GetObject("Выйти.Image")));
            this.Выйти.Location = new System.Drawing.Point(1035, 0);
            this.Выйти.Margin = new System.Windows.Forms.Padding(4);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(32, 30);
            this.Выйти.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выйти.TabIndex = 31;
            this.Выйти.TabStop = false;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.White;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Файл,
            this.Меню,
            this.ПродлитьДоговор,
            this.ОформитьКвартиру,
            this.Профиль});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1067, 27);
            this.toolStrip1.TabIndex = 32;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Файл
            // 
            this.Файл.BackColor = System.Drawing.Color.LightGray;
            this.Файл.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Файл.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вернутьсяКАвторизации,
            this.выйтиИзПриложения});
            this.Файл.Image = ((System.Drawing.Image)(resources.GetObject("Файл.Image")));
            this.Файл.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Файл.Name = "Файл";
            this.Файл.Size = new System.Drawing.Size(59, 24);
            this.Файл.Text = "Файл";
            // 
            // вернутьсяКАвторизации
            // 
            this.вернутьсяКАвторизации.Name = "вернутьсяКАвторизации";
            this.вернутьсяКАвторизации.Size = new System.Drawing.Size(269, 26);
            this.вернутьсяКАвторизации.Text = "Вернуться к авторизации";
            this.вернутьсяКАвторизации.Click += new System.EventHandler(this.вернутьсяКАвторизации_Click);
            // 
            // выйтиИзПриложения
            // 
            this.выйтиИзПриложения.Name = "выйтиИзПриложения";
            this.выйтиИзПриложения.Size = new System.Drawing.Size(269, 26);
            this.выйтиИзПриложения.Text = "Выйти из приложения";
            this.выйтиИзПриложения.Click += new System.EventHandler(this.выйтиИзПриложения_Click);
            // 
            // Меню
            // 
            this.Меню.BackColor = System.Drawing.Color.LightGray;
            this.Меню.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Меню.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вызовы,
            this.группаЗахвата,
            this.договор,
            this.квартиры});
            this.Меню.Image = ((System.Drawing.Image)(resources.GetObject("Меню.Image")));
            this.Меню.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Меню.Name = "Меню";
            this.Меню.Size = new System.Drawing.Size(65, 24);
            this.Меню.Text = "Меню";
            // 
            // вызовы
            // 
            this.вызовы.Name = "вызовы";
            this.вызовы.Size = new System.Drawing.Size(224, 26);
            this.вызовы.Text = "Вызовы";
            this.вызовы.Click += new System.EventHandler(this.вызовы_Click);
            // 
            // группаЗахвата
            // 
            this.группаЗахвата.Name = "группаЗахвата";
            this.группаЗахвата.Size = new System.Drawing.Size(224, 26);
            this.группаЗахвата.Text = "Группа захвата";
            this.группаЗахвата.Click += new System.EventHandler(this.группаЗахвата_Click);
            // 
            // договор
            // 
            this.договор.Name = "договор";
            this.договор.Size = new System.Drawing.Size(224, 26);
            this.договор.Text = "Договор";
            this.договор.Click += new System.EventHandler(this.договор_Click);
            // 
            // квартиры
            // 
            this.квартиры.Name = "квартиры";
            this.квартиры.Size = new System.Drawing.Size(224, 26);
            this.квартиры.Text = "Квартиры";
            this.квартиры.Click += new System.EventHandler(this.квартиры_Click);
            // 
            // ПродлитьДоговор
            // 
            this.ПродлитьДоговор.BackColor = System.Drawing.Color.LightGray;
            this.ПродлитьДоговор.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ПродлитьДоговор.Image = ((System.Drawing.Image)(resources.GetObject("ПродлитьДоговор.Image")));
            this.ПродлитьДоговор.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ПродлитьДоговор.Name = "ПродлитьДоговор";
            this.ПродлитьДоговор.Size = new System.Drawing.Size(143, 24);
            this.ПродлитьДоговор.Text = "Продлить договор";
            this.ПродлитьДоговор.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // ОформитьКвартиру
            // 
            this.ОформитьКвартиру.BackColor = System.Drawing.Color.LightGray;
            this.ОформитьКвартиру.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ОформитьКвартиру.Image = ((System.Drawing.Image)(resources.GetObject("ОформитьКвартиру.Image")));
            this.ОформитьКвартиру.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ОформитьКвартиру.Name = "ОформитьКвартиру";
            this.ОформитьКвартиру.Size = new System.Drawing.Size(153, 24);
            this.ОформитьКвартиру.Text = "Оформить квартиру";
            this.ОформитьКвартиру.Click += new System.EventHandler(this.ОформитьКвартиру_Click);
            // 
            // Профиль
            // 
            this.Профиль.BackColor = System.Drawing.Color.LightGray;
            this.Профиль.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Профиль.Image = ((System.Drawing.Image)(resources.GetObject("Профиль.Image")));
            this.Профиль.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Профиль.Name = "Профиль";
            this.Профиль.Size = new System.Drawing.Size(29, 24);
            this.Профиль.Text = "Профиль";
            this.Профиль.Click += new System.EventHandler(this.Профиль_Click);
            // 
            // Поиск
            // 
            this.Поиск.BackColor = System.Drawing.Color.LightGray;
            this.Поиск.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Поиск.Location = new System.Drawing.Point(696, 1);
            this.Поиск.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Поиск.Name = "Поиск";
            this.Поиск.Size = new System.Drawing.Size(67, 27);
            this.Поиск.TabIndex = 49;
            this.Поиск.Text = "Поиск:";
            // 
            // ПолеПоиск
            // 
            this.ПолеПоиск.BackColor = System.Drawing.Color.LightGray;
            this.ПолеПоиск.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ПолеПоиск.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ПолеПоиск.Location = new System.Drawing.Point(763, 1);
            this.ПолеПоиск.Margin = new System.Windows.Forms.Padding(4);
            this.ПолеПоиск.Multiline = true;
            this.ПолеПоиск.Name = "ПолеПоиск";
            this.ПолеПоиск.ShortcutsEnabled = false;
            this.ПолеПоиск.Size = new System.Drawing.Size(192, 27);
            this.ПолеПоиск.TabIndex = 48;
            this.ПолеПоиск.TextChanged += new System.EventHandler(this.ПолеПоиск_TextChanged);
            // 
            // ТаблицыКП
            // 
            this.ТаблицыКП.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицыКП.Location = new System.Drawing.Point(0, 31);
            this.ТаблицыКП.Margin = new System.Windows.Forms.Padding(4);
            this.ТаблицыКП.Name = "ТаблицыКП";
            this.ТаблицыКП.RowHeadersWidth = 51;
            this.ТаблицыКП.Size = new System.Drawing.Size(1067, 299);
            this.ТаблицыКП.TabIndex = 50;
            // 
            // houseBindingSource
            // 
            this.houseBindingSource.DataMember = "House";
            this.houseBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // уППМ01НеверовДСDataSetBindingSource
            // 
            this.уППМ01НеверовДСDataSetBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            this.уППМ01НеверовДСDataSetBindingSource.Position = 0;
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ПредыдущаяЗапись
            // 
            this.ПредыдущаяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПредыдущаяЗапись.Image")));
            this.ПредыдущаяЗапись.Location = new System.Drawing.Point(489, 332);
            this.ПредыдущаяЗапись.Margin = new System.Windows.Forms.Padding(4);
            this.ПредыдущаяЗапись.Name = "ПредыдущаяЗапись";
            this.ПредыдущаяЗапись.Size = new System.Drawing.Size(47, 43);
            this.ПредыдущаяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПредыдущаяЗапись.TabIndex = 53;
            this.ПредыдущаяЗапись.TabStop = false;
            this.ПредыдущаяЗапись.Click += new System.EventHandler(this.ПредыдущаяЗапись_Click);
            // 
            // СледующаяЗапись
            // 
            this.СледующаяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("СледующаяЗапись.Image")));
            this.СледующаяЗапись.Location = new System.Drawing.Point(544, 332);
            this.СледующаяЗапись.Margin = new System.Windows.Forms.Padding(4);
            this.СледующаяЗапись.Name = "СледующаяЗапись";
            this.СледующаяЗапись.Size = new System.Drawing.Size(47, 43);
            this.СледующаяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.СледующаяЗапись.TabIndex = 52;
            this.СледующаяЗапись.TabStop = false;
            this.СледующаяЗапись.Click += new System.EventHandler(this.pictureBox4_Click_1);
            // 
            // ПерваяЗапись
            // 
            this.ПерваяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПерваяЗапись.Image")));
            this.ПерваяЗапись.Location = new System.Drawing.Point(435, 332);
            this.ПерваяЗапись.Margin = new System.Windows.Forms.Padding(4);
            this.ПерваяЗапись.Name = "ПерваяЗапись";
            this.ПерваяЗапись.Size = new System.Drawing.Size(47, 43);
            this.ПерваяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПерваяЗапись.TabIndex = 54;
            this.ПерваяЗапись.TabStop = false;
            this.ПерваяЗапись.Click += new System.EventHandler(this.ПерваяЗапись_Click);
            // 
            // ПоследняяЗапись
            // 
            this.ПоследняяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПоследняяЗапись.Image")));
            this.ПоследняяЗапись.Location = new System.Drawing.Point(599, 332);
            this.ПоследняяЗапись.Margin = new System.Windows.Forms.Padding(4);
            this.ПоследняяЗапись.Name = "ПоследняяЗапись";
            this.ПоследняяЗапись.Size = new System.Drawing.Size(47, 43);
            this.ПоследняяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПоследняяЗапись.TabIndex = 55;
            this.ПоследняяЗапись.TabStop = false;
            this.ПоследняяЗапись.Click += new System.EventHandler(this.ПоследняяЗапись_Click);
            // 
            // callingBindingSource
            // 
            this.callingBindingSource.DataMember = "Calling";
            this.callingBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // callingTableAdapter
            // 
            this.callingTableAdapter.ClearBeforeFill = true;
            // 
            // captureBindingSource
            // 
            this.captureBindingSource.DataMember = "Capture";
            this.captureBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // captureTableAdapter
            // 
            this.captureTableAdapter.ClearBeforeFill = true;
            // 
            // contractBindingSource
            // 
            this.contractBindingSource.DataMember = "Contract";
            this.contractBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // contractTableAdapter
            // 
            this.contractTableAdapter.ClearBeforeFill = true;
            // 
            // flatBindingSource
            // 
            this.flatBindingSource.DataMember = "Flat";
            this.flatBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // flatTableAdapter
            // 
            this.flatTableAdapter.ClearBeforeFill = true;
            // 
            // flatHouseBindingSource
            // 
            this.flatHouseBindingSource.DataMember = "Flat-House";
            this.flatHouseBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // flat_HouseTableAdapter
            // 
            this.flat_HouseTableAdapter.ClearBeforeFill = true;
            // 
            // houseTableAdapter
            // 
            this.houseTableAdapter.ClearBeforeFill = true;
            // 
            // prolongingBindingSource
            // 
            this.prolongingBindingSource.DataMember = "Prolonging";
            this.prolongingBindingSource.DataSource = this.уППМ01НеверовДСDataSetBindingSource;
            // 
            // prolongingTableAdapter
            // 
            this.prolongingTableAdapter.ClearBeforeFill = true;
            // 
            // КП
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(1067, 380);
            this.Controls.Add(this.ПоследняяЗапись);
            this.Controls.Add(this.ПерваяЗапись);
            this.Controls.Add(this.ПредыдущаяЗапись);
            this.Controls.Add(this.СледующаяЗапись);
            this.Controls.Add(this.ТаблицыКП);
            this.Controls.Add(this.Поиск);
            this.Controls.Add(this.ПолеПоиск);
            this.Controls.Add(this.Выйти);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "КП";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Форма конечного пользователя";
            this.Load += new System.EventHandler(this.КП_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.КП_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.КП_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицыКП)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уППМ01НеверовДСDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПредыдущаяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.СледующаяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПерваяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПоследняяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Выйти;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton Файл;
        private System.Windows.Forms.ToolStripButton ОформитьКвартиру;
        private System.Windows.Forms.ToolStripMenuItem вернутьсяКАвторизации;
        private System.Windows.Forms.ToolStripMenuItem выйтиИзПриложения;
        private System.Windows.Forms.ToolStripButton ПродлитьДоговор;
        private System.Windows.Forms.Label Поиск;
        private System.Windows.Forms.TextBox ПолеПоиск;
        private System.Windows.Forms.ToolStripDropDownButton Меню;
        private System.Windows.Forms.ToolStripMenuItem вызовы;
        private System.Windows.Forms.ToolStripMenuItem группаЗахвата;
        private System.Windows.Forms.ToolStripButton Профиль;
        private System.Windows.Forms.DataGridView ТаблицыКП;
        private System.Windows.Forms.PictureBox ПредыдущаяЗапись;
        private System.Windows.Forms.PictureBox СледующаяЗапись;
        private System.Windows.Forms.PictureBox ПерваяЗапись;
        private System.Windows.Forms.PictureBox ПоследняяЗапись;
        private System.Windows.Forms.BindingSource уППМ01НеверовДСDataSetBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource callingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter callingTableAdapter;
        private System.Windows.Forms.BindingSource captureBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter captureTableAdapter;
        private System.Windows.Forms.BindingSource contractBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter contractTableAdapter;
        private System.Windows.Forms.BindingSource flatBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter flatTableAdapter;
        private System.Windows.Forms.BindingSource flatHouseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter flat_HouseTableAdapter;
        private System.Windows.Forms.BindingSource houseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter houseTableAdapter;
        private System.Windows.Forms.BindingSource prolongingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter prolongingTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem договор;
        private System.Windows.Forms.ToolStripMenuItem квартиры;
    }
}