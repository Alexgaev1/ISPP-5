﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Командир : Form
    {
        public Командир()
        {
            InitializeComponent();
        }
        int i, c, index,a; 
        Point Mouse;
        private void tab (int c)
        {
            SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = уП_ПМ_01_Неверов_ДС; Integrated Security = True");
            sqlConnect.Open();
            SqlDataAdapter[] sa = new SqlDataAdapter[5];
            sa[1] = new SqlDataAdapter("SELECT [SecondName], [FirstName], [ThirdName], [Address], [Phone], [AddressFlat], [Floor], [TypeDoor], [Balcony], [TypeBalcony], [FlatPlan], [Floors], [Key] FROM [Flat-House] INNER JOIN Flat ON [Flat-House].FlatID = Flat.FlatID INNER JOIN [Settlement] ON Flat.FlatID = Settlement.FlatID INNER JOIN [Client] ON Settlement.Registr = Client.Registr INNER JOIN [House] ON [Flat-House].HouseID = House.HouseID", sqlConnect);
            sa[2] = new SqlDataAdapter("SELECT [SecondName], [FirstName], [ThirdName], [Address], [Phone], [DateStart], [StopDate], [Cost] FROM [Client] INNER JOIN [Settlement] ON Client.Registr = Settlement.Registr INNER JOIN [Contract] ON Settlement.SettlementID = Contract.SettlementID", sqlConnect);
            sa[3] = new SqlDataAdapter("SELECT * from [Calling]", sqlConnect);
            sa[4] = new SqlDataAdapter("SELECT * from [Capture]", sqlConnect);
            DataSet ds = new DataSet();
            sa[c].Fill(ds);
            ТаблицыКомандир.DataSource = ds.Tables[0];
        }
        private void Командир_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Capture". При необходимости она может быть перемещена или удалена.
            this.captureTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Capture);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Calling". При необходимости она может быть перемещена или удалена.
            this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Calling);
            Надпись6.Visible = false;
            Надпись7.Visible = false;
            Надпись5.Visible = false;
            Надпись4.Visible = false;
            Надпись3.Visible = false;
            Надпись2.Visible = false;
            Надпись1.Visible = false;
            УдалитьЗапись.Visible = false;
            ОбновитьТаблицу.Visible = false;
            ДодбавитьЗапись.Visible = false;
            Вызовы.Visible = false;
            Захват.Visible = false;
            ТаблицыКомандир.Size = new Size(755, 274);
            this.Size = new Size(755, 341);
            c = 1;
            tab(c);
        }

        private void КвартираКлиента_Click(object sender, EventArgs e)
        {
            ТаблицыКомандир.Size = new Size(755, 274);
            c = 1;
            tab(c);
            УдалитьЗапись.Visible = false;
            ОбновитьТаблицу.Visible = false;
            ДодбавитьЗапись.Visible = false;
            Захват.Visible=false;
            Вызовы.Visible=false;
            Надпись1.Visible = false; 
            Надпись2.Visible = false;    
            Надпись3.Visible = false;
            Надпись4.Visible = false;
            Надпись5.Visible = false;
            Надпись6.Visible = false;
            Надпись7.Visible = false;
        }

        private void Договоры_Click(object sender, EventArgs e)
        {
            ТаблицыКомандир.Size = new Size(755, 274);
            c = 2;
            tab(c);
            УдалитьЗапись.Visible = false;
            ОбновитьТаблицу.Visible = false;
            ДодбавитьЗапись.Visible = false;
            Захват.Visible = false;
            Вызовы.Visible = false;
            Надпись1.Visible = false;
            Надпись2.Visible = false;
            Надпись3.Visible = false;
            Надпись4.Visible = false;
            Надпись5.Visible = false;
            Надпись6.Visible = false;
            Надпись7.Visible = false;
        }

        private void ВыйтиИзПриложения_Click(object sender, EventArgs e)
        {
            //Выход из приложения
            Application.Exit();
        }
        private void ГруппаЗахвата_Click(object sender, EventArgs e)
        {
            ТаблицыКомандир.Size = new Size(480, 274);
            c = 4;
            tab(c);
            УдалитьЗапись.Visible = true;
            ОбновитьТаблицу.Visible = true;
            ДодбавитьЗапись.Visible = true;
            Надпись6.Visible = false;
            Надпись7.Visible = false;
            Надпись5.Visible = true;
            Надпись4.Visible = true;
            Надпись3.Visible = true;
            Надпись2.Visible = true;
            Надпись1.Visible = true;
            Надпись1.Text = ТаблицыКомандир.Columns[0].HeaderText;
            Надпись2.Text = ТаблицыКомандир.Columns[1].HeaderText;
            Надпись3.Text = ТаблицыКомандир.Columns[2].HeaderText;
            Надпись4.Text = ТаблицыКомандир.Columns[3].HeaderText;
            Надпись5.Text = ТаблицыКомандир.Columns[4].HeaderText;
            Вызовы.Visible = false;
            Захват.Visible = true;
            Захват.Location = new Point(621, 27);
        }
        private void Вызовы_Click(object sender, EventArgs e)
        {
            ТаблицыКомандир.Size = new Size(480, 274);
            c = 3;
            tab(c);
            УдалитьЗапись.Visible = true;
            ОбновитьТаблицу.Visible = true;
            ДодбавитьЗапись.Visible = true;
            Надпись6.Visible = true;
            Надпись7.Visible = true;
            Надпись5.Visible = true;
            Надпись4.Visible = true;
            Надпись3.Visible = true;
            Надпись2.Visible = true;
            Надпись1.Visible = true;
            Надпись1.Text = ТаблицыКомандир.Columns[0].HeaderText;
            Надпись2.Text = ТаблицыКомандир.Columns[1].HeaderText;
            Надпись3.Text = ТаблицыКомандир.Columns[2].HeaderText;
            Надпись4.Text = ТаблицыКомандир.Columns[3].HeaderText;
            Надпись5.Text = ТаблицыКомандир.Columns[4].HeaderText;
            Надпись6.Text = ТаблицыКомандир.Columns[5].HeaderText;
            Надпись7.Text = ТаблицыКомандир.Columns[6].HeaderText;
            Захват.Visible = false;
            Вызовы.Visible = true;
        }

        private void Выйти_Click(object sender, EventArgs e)
        {
            //выход из придожения
            Application.Exit();
        }

        private void ПерваяЗапись_Click(object sender, EventArgs e)
        {
            //переход на первую строку таблицы
            ТаблицыКомандир.CurrentCell = ТаблицыКомандир[0, 0];
        }

        private void ПредыдущаяЗапись_Click(object sender, EventArgs e)
        {
            //переход на предыдущую строку таблицы
            i = ТаблицыКомандир.RowCount;
            index = ТаблицыКомандир.CurrentRow.Index;
            if (index <= 0)
            {
                ТаблицыКомандир.CurrentCell = ТаблицыКомандир[0, i - 1];
            }
            else
            {
                ТаблицыКомандир.Rows[index].Selected = true;
                ТаблицыКомандир.CurrentCell = ТаблицыКомандир[0, index - 1];
            }
        }

        private void СледующаяЗапись_Click(object sender, EventArgs e)
        {
            //переход на следующую строку таблицы
            i = ТаблицыКомандир.RowCount;
            index = ТаблицыКомандир.CurrentRow.Index;
            if (index >= (i - 1))
            {
                ТаблицыКомандир.CurrentCell = ТаблицыКомандир[0, 0];
            }
            else
            {
                ТаблицыКомандир.Rows[index].Selected = true;
                ТаблицыКомандир.CurrentCell = ТаблицыКомандир[0, index + 1];
            }
        }

        private void УдалитьЗапись_Click(object sender, EventArgs e)
        {
            //удаление строки выделеной строки таблицы 
            for (int i = 0; i < ТаблицыКомандир.RowCount; i++)
            {
                for (int j = 0; j < ТаблицыКомандир.ColumnCount; j++)
                {
                    if (ТаблицыКомандир.Rows[i].Cells[j].Selected == true)
                    {
                        ТаблицыКомандир.Rows.Remove(ТаблицыКомандир.Rows[i]);
                        switch (c)
                        {
                            case 4: captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture); break;
                            case 3: callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling); break;
                        }

                    }
                }
            }
        }

        private void ДобавитьЗапись_Click(object sender, EventArgs e)
        {
            //Добавление новой строки в таблицу
            switch (c)
            {
                case 3:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Calling] VALUES ('{CallingID.Text}','{TreatyID.Text}','{ActionID.Text}','{ДатаВызова.Text}','{a}','{Штраф.Text}','{Компенсация.Text}');", sqlConnect);
                        da.Fill(dt);
                        CallingID.Text = "";
                        TreatyID.Text = "";
                        ActionID.Text = "";
                        Штраф.Text = "";
                        Компенсация.Text = "";
                        Вызов.Checked = false;
                        ДатаВызова.Text = "";
                    }
                    break;
                case 4:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Capture] VALUES ('{ПолеКодГруппыЗахвата.Text}','{НомерЭкипажа.Text}','{КомандирЭкипажа.Text}','{Автомобиль.Text}','{Документ.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодГруппыЗахвата.Text = "";
                        НомерЭкипажа.Text = "";
                        КомандирЭкипажа.Text = "";
                        Автомобиль.Text = "";
                        Документ.Text = "";
                    }
                    break;
            }
        }

        private void ОбновитьТаблицу_Click(object sender, EventArgs e)
        {
            //обновлpictureBox7_Clickение данных таблиц баз данных
            switch (c)
            {
                case 4: captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture); break;
                case 3: callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling); break;
            }
        }

        private void Вызов_CheckedChanged(object sender, EventArgs e)
        {
            if (Вызов.Checked == true)
            {
                a = 1;
            }
            else if (Вызов.Checked == false)
            {
                a = 0;
            }
        }

        private void ПоследняяЗапись_Click(object sender, EventArgs e)
        {
            //переход на последнюю строку таблицы
            ТаблицыКомандир.ClearSelection(); //снять выделение всех выбранных ячеек
            index = ТаблицыКомандир.Rows.Count - 1; // индекс последней строки
            ТаблицыКомандир.Rows[index].Selected = true; // выделить нужную строку
            ТаблицыКомандир.FirstDisplayedScrollingRowIndex = index; // фокус в нужную строку
        }

        private void CallingID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TreatyID.Focus();
            }
        }

        private void TreatyID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ActionID.Focus();
            }
        }

        private void ActionID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ДатаВызова.Focus();
            }
        }

        private void Штраф_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                Компенсация.Focus();
            }
        }

        private void ПолеКодГруппыЗахвата_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                НомерЭкипажа.Focus();
            }
        }

        private void НомерЭкипажа_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                КомандирЭкипажа.Focus();
            }
        }

        private void КомандирЭкипажа_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                Автомобиль.Focus();
            }
        }

        private void Автомобиль_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                Документ.Focus();
            }
        }

        private void ВернутьсяКАвторизации_Click(object sender, EventArgs e)
        {
            //переход на форму авторизация
            Авторизация fd = new Авторизация();
            fd.Show();
            Hide();
        }

        private void Надпись5_Click(object sender, EventArgs e)
        {

        }

        private void ПолеПоиск_TextChanged(object sender, EventArgs e)
        {
            //поиск в таблице
            for (int i = 0; i < ТаблицыКомандир.RowCount; i++)
            {
                ТаблицыКомандир.Rows[i].Selected = false;
                for (int j = 0; j < ТаблицыКомандир.ColumnCount; j++)
                {
                    if (ТаблицыКомандир.Rows[i].Cells[j].Value != null)
                    {
                        if (ТаблицыКомандир.Rows[i].Cells[j].Value.ToString().Contains(ПолеПоиск.Text))
                        {
                            ТаблицыКомандир.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }
        
        private void Командир_MouseDown(object sender, MouseEventArgs e)
        {
            //отпеделяет точку где была эажата клавиша мыши на форме
            Mouse = new Point(e.X, e.Y);
        }

        private void Командир_MouseMove(object sender, MouseEventArgs e)
        {
            //передвигает форму по тому как движется мышка по экрану
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }
    }
}