﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Профиль : Form
    {
        public Профиль()
        {
            InitializeComponent();
        }
        string reg;
        public void ind(string i)
        {
             reg = i;
            for (int j = 0; j < dataGridView1.RowCount; j++)
            {

                if (dataGridView1.Rows[j].Cells[0].Value.ToString().Contains(i))
                {
                    dataGridView1.Rows[j].Selected = true;
                    dataGridView1.CurrentCell = dataGridView1[0, j];
                    break;
                }
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.CurrentCell = dataGridView1[0, 0];
            ind(reg);
            clientTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Client);
            
            MessageBox.Show("Ваши данные были обновлены");
        }

        private void Профиль_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            ToolTip tt = new ToolTip();
            tt.SetToolTip(button1, "Нажмите, чтобы подтвердить изменение");
            this.Size = new Size(208, 242);
        }
        Point Mouse;
        private void Профиль_MouseDown(object sender, MouseEventArgs e)
        {
            Mouse = new Point(e.X, e.Y);
        }

        private void Профиль_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - Mouse.X;
                Top += e.Y - Mouse.Y;
            }
        }
    }
}
