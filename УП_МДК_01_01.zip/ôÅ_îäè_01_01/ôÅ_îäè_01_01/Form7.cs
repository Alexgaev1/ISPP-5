﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace УП_МДК_01_01
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП01_ИСПП5_Работягова_ААDataSet3.Квартиры". При необходимости она может быть перемещена или удалена.
            this.квартирыTableAdapter2.Fill(this.уП01_ИСПП5_Работягова_ААDataSet3.Квартиры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП01_ИСПП5_Работягова_ААDataSet2.Квартиры". При необходимости она может быть перемещена или удалена.
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП01_ИСПП5_Работягова_ААDataSet3.План_квартир". При необходимости она может быть перемещена или удалена.
            this.план_квартирTableAdapter1.Fill(this.уП01_ИСПП5_Работягова_ААDataSet3.План_квартир);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                квартирыTableAdapter2.Update(уП01_ИСПП5_Работягова_ААDataSet3.Квартиры);
            план_квартирTableAdapter1.Update(уП01_ИСПП5_Работягова_ААDataSet3.План_квартир);
        }
        string a;
        public void st(string s)
        {
            a = s;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Form5 form5 = new Form5();
            form5.Show();
            form5.ii(a);
            
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {

            
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            
        }
       
        private void btnSelect_Click(object sender, EventArgs e)
        {
        }

        
        private void btnSet_Click(object sender, EventArgs e)
        {
            
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureSet_Click(object sender, EventArgs e)
        {
            pictureSet.SizeMode = PictureBoxSizeMode.StretchImage;

        }

        private void pictureView_Click(object sender, EventArgs e)
        {
            

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
