﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace УП_МДК_01_01
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП01_ИСПП5_Работягова_ААDataSet3.Дома". При необходимости она может быть перемещена или удалена.
            this.домаTableAdapter2.Fill(this.уП01_ИСПП5_Работягова_ААDataSet3.Дома);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП01_ИСПП5_Работягова_ААDataSet3.Фотографии_домов". При необходимости она может быть перемещена или удалена.
            this.фотографии_домовTableAdapter1.Fill(this.уП01_ИСПП5_Работягова_ААDataSet3.Фотографии_домов);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            домаTableAdapter2.Update(уП01_ИСПП5_Работягова_ААDataSet3.Дома);
            фотографии_домовTableAdapter1.Update(уП01_ИСПП5_Работягова_ААDataSet3.Фотографии_домов);
        }
        public string dost;
        public void i(string b)
        {
            dost = b;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (dost == "Администратор")
            {
                Hide();
                Form5 form5 = new Form5();
                form5.Show();
            }
            else if (dost == "Клиент")
            {
                Hide();
                Form10 form10 = new Form10();
                form10.Show();
            }
            else
            {
                Hide();
                Form11 form11 = new Form11();
                form11.Show();
            }
        }

        private void pictureView_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureSet_Click(object sender, EventArgs e)
        {
            pictureSet.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            pictureSet.Image = Image.FromFile(label1.Text); ;
        }
    }
}
