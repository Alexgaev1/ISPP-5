﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace УП_МДК_01_01
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            агентыTableAdapter1.Update(уП01_ИСПП5_Работягова_ААDataSet1.Агенты);
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП01_ИСПП5_Работягова_ААDataSet1.Агенты". При необходимости она может быть перемещена или удалена.
            this.агентыTableAdapter1.Fill(this.уП01_ИСПП5_Работягова_ААDataSet1.Агенты);

        }
        string a;
        public void st(string s)
        {
            a = s;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Form5 form5 = new Form5();
            form5.Show();
            form5.ii(a);
           
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            агентыTableAdapter1.Update(уП01_ИСПП5_Работягова_ААDataSet1.Агенты);
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            агентыBindingSource1.CancelEdit();
        }
    }
}
